﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PointIndexerWindowApp
{
    
    class Point
    {
        /* 멤버변수(: 정수형 x , y 좌표를 표현할 정수형 변수) */
        int x, y;

        /* 생성자 */
        // 매개변수 x,y 값으로 맴버변수를 초기화
        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        // 맴버변수를  각각 0으로 초기화
        public Point()
        {
            x = y = 0;
        }

        /* 메서드 */
        // x에 대한 프로퍼티 작성
        public int X
        {
            get { return x; }
            set { this.x = value; }
        }
        // y에 대한 프로퍼티 작성
        public int Y
        {
            get { return y; }
            set { this.y = value; }
        }
        /* MoveTo(int x,int y) 메서드 구현 */
        public void MoveTo(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        /* MoveBy(int moveX ,int moveY) 메서드 구현 */
        public void MoveBy(int moveX, int moveY)
        {
            x = x + moveX;
            y = y + moveY;
        }
        /* x,y의 좌표정보를 문자열로 제공하기위한 ToString() 메서드 재정의 */
        public override string ToString()
        {
            return "x: " + x + ", y: " + y + Environment.NewLine;
        }
        // 두 포인터 객체의 좌표를 더하고 빼기위한 + 와 -연산자를 재정의 
        /* + 연산자 재정의 */
        public static Point operator + (Point p1, Point p2)
        {
            Point p = new Point(p1.x + p2.x, p1.y + p2.y);
            return p;
        }
        /* - 연산자 재정의 */
        public static Point operator - (Point p1, Point p2)
        {
            Point p = new Point(p1.x - p2.x, p1.y - p2.y);

            return p;
        }

    }
}
