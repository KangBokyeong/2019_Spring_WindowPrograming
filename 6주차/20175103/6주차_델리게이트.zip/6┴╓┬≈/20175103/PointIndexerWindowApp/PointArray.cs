﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PointIndexerWindowApp
{
    
    class PointArray
    {
        Point[] p = new Point[10];  // Point 변수 배열
        public static int count = 0;  //배열 인덱스
        

        /* 멤버 메서드: 배열에 Point 객체를 저장하고 읽어오기 위한 인덱서 */
        public Point this[int index]
        {
            get { return p[index]; }
            set { p[index] = value; }
        }
        


    }
}
