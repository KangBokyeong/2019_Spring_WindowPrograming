﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// 프로젝트명: PointIndexerWindowApp
/// 프로젝트 설명: x, y의 좌표 정보의 객체를 생성 및 출력, 그리고 좌표 변경하는 윈도우 프로그램이다.
/// 작성일: 2019.04.05(금)
/// 학번, 학과: 20175103, 빅데이터전공
/// 작성자: 강보경
/// </summary>
namespace PointIndexerWindowApp
{   
    /* 델리게이트 정의 */
    delegate void MoveDelegate(int x, int y);

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /* 객체에 정보 저장 */
        PointArray p = new PointArray();
        MoveDelegate move = null;
        private void btnCrtObj_Click(object sender, EventArgs e)
        {
            Point point = null;
            if (txtX.Text != null && txtY.Text != null)
                point = new Point(Convert.ToInt32(txtX.Text), Convert.ToInt32(txtY.Text));
            else
                point = new Point();

            p[PointArray.count++] = point;
            move += new MoveDelegate(point.MoveBy);
        }
        /* 객체에 저장이 되어있는 모든 정보 출력하기 */
        private void btnPrintInfo_Click(object sender, EventArgs e)
        {
            // 텍스트박스가 비어있지 않을 때, 일단 초기화하고 시작
            if (txtResult.Text != null)
            {
                txtResult.Text = "";
            }
            // 누적해서 텍스트박스에 출력
            for (int i = 0; i < PointArray.count; i++)
            {
                txtResult.Text += Convert.ToString(p[i]);
            }
        }
        /* Moveby를 호출하여 모두 이동하기 */ 
        // (델리게이트를 호출하고 사용하는 방법은 아직 몰르겠다.)
        private void btnMoveAll_Click(object sender, EventArgs e)
        {
            move(Convert.ToInt32(txtX.Text), Convert.ToInt32(txtY.Text));
            //for (int i = 1; i < PointArray.count; i++)
            //{
           // 
            //    p[i].MoveBy(Convert.ToInt32(txtX.Text), Convert.ToInt32(txtY.Text));
            //}
        }
    }
}
