﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// 프로젝트명: BookInfoWindowApp
/// 프로젝트 설명: eBook에 대한 정보를 저장하고, 저장한 정보를 바탕으로 할인을 하고, 품절 여부를 변경해주며, 전체적으로 출력하는 윈도우 프로그램이다. 
/// 작성일: 2019.04.04(목)
/// 학번, 학과: 20175103, 빅데이터전공
/// 작성자: 강보경
/// </summary>
namespace BookInfoWindowApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // 초기화 시 null로 초기화 해주는 것을 권장.
        EBook eBook = null;
        /* 텍스트박스에 있는 내용을 저장 */
        private void btnSave_Click(object sender, EventArgs e)
        {
            eBook = new EBook(txtTitle.Text, txtAuthor.Text, Convert.ToInt32(txtPages.Text), txtISBN.Text, txtPublisher.Text, Convert.ToInt32(txtPrice.Text));
        }

        /* 텍스트에 쓰여진 만큼을 빼주는 메서드 호출 */
        private void btnSale_Click(object sender, EventArgs e)
        {
            if(eBook != null)
                ((Sale)eBook).DiscountPrice(Convert.ToInt32(txtDiscount.Text));
        }

        /* 품절이면 품절이 아니게, 품절이 아니면 품절이게 만들기 */
        private void btnOfS_Click(object sender, EventArgs e)
        {
            if (eBook.OutOfStock)
            {
                ((Sale)eBook).StorageInWareHouse();
            } else
            {
                ((Sale)eBook).StockOut();
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            txtResult.Text = eBook.ToString();
        }
    }
}
