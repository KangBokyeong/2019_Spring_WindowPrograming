﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookInfoWindowApp
{
    /* 인터페이스 작성 */
    public interface Sale
    {
        void DiscountPrice(int discount);   // 가격을 조정
        void StockOut();                    // 품절여부 변경 (재고 없음)
        void StorageInWareHouse();          // 품절여부 변경 (재고 있음)
    }

    class Book
    {
        /* 멤버변수 */
        string title;   // 책 제목
        string author;  // 책 저자
        int page;       // 쪽 수
        string ISBN;    // 국제표준도서번호
        string publisher;   // 출판사
        
        /* 생성자 */
        public Book(string title, string author, int page, string ISBN, string publisher)
        {
            this.title = title;
            this.author = author;
            this.page = page;
            this.ISBN = ISBN;
            this.publisher = publisher;
        }

        /* title에 대한 get/set 프로퍼티 */
        public string Title
        {
            get { return title; }
            set { this.title = value; }
        }
        /* Book의 정보를 출력하기 위한 ToString() 메서드 재정의 */
        public override string ToString()
        {
            string str = "Title: " + title + "/Author: " + author + "/Pages: " + page + "/ISBN: " + ISBN + "/Publisher: " + publisher;
            return str;
        }
    }
    
}
