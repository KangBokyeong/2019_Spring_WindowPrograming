﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookInfoWindowApp
{
    class EBook : Book, Sale
    {
        /* 멤버변수 */
        int price;   // 가격
        bool outOfStock = false;    // 품절 유무

        /* 생성자: EBook에 대한 정보는 상위클래스 생성자를 통해서 초기화  */
        public EBook(string title, string author, int page, string ISBN, string publisher, int price):base(title, author, page, ISBN, publisher)
        {
            this.price = price;
        }

        /* price에 대한 get/set 프로퍼티 */
        public int Price
        {
            get { return price; }
            set { this.price = value; }
        }
        /* outOfStock에 대한 get/set 프로퍼티 */
        public bool OutOfStock
        {
            get { return outOfStock; }
            set { this.outOfStock = value; }
        }
        
        /* EBook의 정보를 출력하기 위한 ToString() 메서드 재정의 */
        public override string ToString()
        {
            string stock_status = !outOfStock ? "재고 있음" : "품절";
            string str = base.ToString() + "/price: " + price + "/" + stock_status;
            return str;
        }

        /* 가격을 조정 ( price - discount ) */
        void Sale.DiscountPrice(int discount)
        {
            this.price = this.price - discount;
        }
        /* 품절여부를 true 로 조정 */
        void Sale.StockOut()
        {
            this.outOfStock = true;
        }
        /* 품절여부를 false 로 조정 */
        void Sale.StorageInWareHouse()
        {
            this.outOfStock = false;
        }
    }
}
