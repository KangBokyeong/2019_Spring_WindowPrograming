﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PointAndColorable3DPoint
{
    class Colorable3DPoint : Point
    {
        // 추가 멤버 변수
        int z;
        string color;
        // 생성자
        public Colorable3DPoint(int x, int y, int z, string color) : base(x, y)
        {
            this.z = z;
            this.color = color;
        }
        /* z, color의 get, set 메서드 */
        // z의 get, set 메서드
        public int getZ()
        {
            return z;
        }
        public void setZ(int z)
        {
            this.z = z;
        }
        // color의 get, set 메서드
        public string getColor()
        {
            return color;
        }
        public void setColor(string color)
        {
            this.color = color;
        }

        // MoveTo 메서드 구현
        public void MoveTo(int x, int y, int z) 
        {
            base.MoveTo(x, y);
            this.z = z;
        }
        // MoveBy 매서드 구현
        public void MoveBy(int moveX, int moveY, int moveZ)
        {
            base.MoveBy(moveX, moveY);
            z = z + moveZ;
        }

        // 아래는 사용 안함.
        // x, y의 좌표정보를 문자열로 제공하기 위한 ToString()메서드 재정의
        public override string ToString()
        {
            return "x: ";
        }
    }
}
