﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// 프로그램명: PointAndColorable3DPoint
/// 프로그램 설명: Point 클래스를 상속받는 Colorable3DPoint 클래스를 작성하고 생성하는 윈도우 프로그램이다.
/// 작성일: 2019.03.28(목)
/// 학번, 학과: 20175103, 빅데이터전공
/// 작성자: 강보경
/// </summary>
namespace PointAndColorable3DPoint
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Colorable3DPoint p;
        // x축만 변경
        private void btn_x_Click(object sender, EventArgs e)
        {
            p.setX(Convert.ToInt32(txt_x_before.Text));
            txt_x_after.Text = Convert.ToString(p.getX());
        }
        // y축만 변경
        private void btn_y_Click(object sender, EventArgs e)
        {
            p.setY(Convert.ToInt32(txt_y_before.Text));
            txt_y_after.Text = Convert.ToString(p.getY());
        }
        // z축만 변경
        private void btn_z_Click(object sender, EventArgs e)
        {
            p.setZ(Convert.ToInt32(txt_z_before.Text));
            txt_z_after.Text = Convert.ToString(p.getZ());
        }
        // 색만 변경
        private void btn_color_Click(object sender, EventArgs e)
        {
            p.setColor(txt_color_before.Text);
            txt_color_after.Text = p.getColor();
        }
        // 객체 생성
        private void btn_create_obj_Click(object sender, EventArgs e)
        {
            p = new Colorable3DPoint(Convert.ToInt32(txt_x_before.Text), Convert.ToInt32(txt_y_before.Text), Convert.ToInt32(txt_z_before.Text), txt_color_before.Text);
            txt_x_after.Text = Convert.ToString(p.getX());
            txt_y_after.Text = Convert.ToString(p.getY());
            txt_z_after.Text = Convert.ToString(p.getZ());
            txt_color_after.Text = p.getColor();
        }
        // 변경
        private void btn_MoveTo_Click(object sender, EventArgs e)
        {
            p.MoveTo(Convert.ToInt32(txt_x_before.Text), Convert.ToInt32(txt_y_before.Text), Convert.ToInt32(txt_z_before.Text));
            txt_x_after.Text = Convert.ToString(p.getX());
            txt_y_after.Text = Convert.ToString(p.getY());
            txt_z_after.Text = Convert.ToString(p.getZ());
        }
        // 이동
        private void btn_MoveBy_Click(object sender, EventArgs e)
        {
            p.MoveBy(Convert.ToInt32(txt_x_before.Text), Convert.ToInt32(txt_y_before.Text), Convert.ToInt32(txt_z_before.Text));
            txt_x_after.Text = Convert.ToString(p.getX());
            txt_y_after.Text = Convert.ToString(p.getY());
            txt_z_after.Text = Convert.ToString(p.getZ());
        }

        
    }
}
