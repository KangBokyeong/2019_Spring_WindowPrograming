﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PointAndColorable3DPoint
{
    class Point
    {
        // 맴버변수 x, y 좌표를 표현할 정수형 변수
        int x;
        int y;
        
        // 매개변수 x,y 값으로 맴버변수 초기화
        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        /* x, y의 get, set 메서드 */
        // x의 get, set 메서드
        public int getX()
        {
            return x;
        }
        public void setX(int x)
        {
            this.x = x;
        }
        // y의 get, set 메서드
        public int getY()
        {
            return y;
        }
        public void setY(int y)
        {
            this.y = y;
        }
        // MoveTo 메서드 구현
        public void MoveTo(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        // MoveBy 매서드 구현
        public void MoveBy(int moveX, int moveY)
        {
            x = x + moveX;
            y = y + moveY;
        }
        // x, y의 좌표정보를 문자열로 제공하기 위한 ToString()메서드 재정의
        public override string ToString()
        {
            return "x: " + x + ", y: " + y;
        }

    }
}
