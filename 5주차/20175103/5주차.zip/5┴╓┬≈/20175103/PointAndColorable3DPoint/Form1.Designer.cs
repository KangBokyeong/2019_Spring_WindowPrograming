﻿namespace PointAndColorable3DPoint
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_x_before = new System.Windows.Forms.TextBox();
            this.txt_y_before = new System.Windows.Forms.TextBox();
            this.txt_z_before = new System.Windows.Forms.TextBox();
            this.txt_color_before = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_x_before = new System.Windows.Forms.Label();
            this.lbl_y_before = new System.Windows.Forms.Label();
            this.lbl_z_before = new System.Windows.Forms.Label();
            this.lbl_color_before = new System.Windows.Forms.Label();
            this.lbl_color_after = new System.Windows.Forms.Label();
            this.lbl_z_after = new System.Windows.Forms.Label();
            this.lbl_y_after = new System.Windows.Forms.Label();
            this.lbl_x_after = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_color_after = new System.Windows.Forms.TextBox();
            this.txt_z_after = new System.Windows.Forms.TextBox();
            this.txt_y_after = new System.Windows.Forms.TextBox();
            this.txt_x_after = new System.Windows.Forms.TextBox();
            this.btn_x = new System.Windows.Forms.Button();
            this.btn_y = new System.Windows.Forms.Button();
            this.btn_z = new System.Windows.Forms.Button();
            this.btn_color = new System.Windows.Forms.Button();
            this.btn_create_obj = new System.Windows.Forms.Button();
            this.btn_MoveTo = new System.Windows.Forms.Button();
            this.btn_MoveBy = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_x_before
            // 
            this.txt_x_before.BackColor = System.Drawing.Color.MistyRose;
            this.txt_x_before.Location = new System.Drawing.Point(143, 82);
            this.txt_x_before.Name = "txt_x_before";
            this.txt_x_before.Size = new System.Drawing.Size(100, 25);
            this.txt_x_before.TabIndex = 0;
            // 
            // txt_y_before
            // 
            this.txt_y_before.BackColor = System.Drawing.Color.MistyRose;
            this.txt_y_before.Location = new System.Drawing.Point(143, 134);
            this.txt_y_before.Name = "txt_y_before";
            this.txt_y_before.Size = new System.Drawing.Size(100, 25);
            this.txt_y_before.TabIndex = 1;
            // 
            // txt_z_before
            // 
            this.txt_z_before.BackColor = System.Drawing.Color.MistyRose;
            this.txt_z_before.Location = new System.Drawing.Point(143, 192);
            this.txt_z_before.Name = "txt_z_before";
            this.txt_z_before.Size = new System.Drawing.Size(100, 25);
            this.txt_z_before.TabIndex = 2;
            // 
            // txt_color_before
            // 
            this.txt_color_before.BackColor = System.Drawing.Color.MistyRose;
            this.txt_color_before.Location = new System.Drawing.Point(143, 251);
            this.txt_color_before.Name = "txt_color_before";
            this.txt_color_before.Size = new System.Drawing.Size(100, 25);
            this.txt_color_before.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(87, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "좌표 생성 및 변경";
            // 
            // lbl_x_before
            // 
            this.lbl_x_before.AutoSize = true;
            this.lbl_x_before.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_x_before.Location = new System.Drawing.Point(57, 87);
            this.lbl_x_before.Name = "lbl_x_before";
            this.lbl_x_before.Size = new System.Drawing.Size(29, 15);
            this.lbl_x_before.TabIndex = 5;
            this.lbl_x_before.Text = "X :";
            // 
            // lbl_y_before
            // 
            this.lbl_y_before.AutoSize = true;
            this.lbl_y_before.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_y_before.Location = new System.Drawing.Point(57, 139);
            this.lbl_y_before.Name = "lbl_y_before";
            this.lbl_y_before.Size = new System.Drawing.Size(28, 15);
            this.lbl_y_before.TabIndex = 6;
            this.lbl_y_before.Text = "Y :";
            // 
            // lbl_z_before
            // 
            this.lbl_z_before.AutoSize = true;
            this.lbl_z_before.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_z_before.Location = new System.Drawing.Point(57, 197);
            this.lbl_z_before.Name = "lbl_z_before";
            this.lbl_z_before.Size = new System.Drawing.Size(29, 15);
            this.lbl_z_before.TabIndex = 7;
            this.lbl_z_before.Text = "Z :";
            // 
            // lbl_color_before
            // 
            this.lbl_color_before.AutoSize = true;
            this.lbl_color_before.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_color_before.Location = new System.Drawing.Point(57, 256);
            this.lbl_color_before.Name = "lbl_color_before";
            this.lbl_color_before.Size = new System.Drawing.Size(47, 15);
            this.lbl_color_before.TabIndex = 8;
            this.lbl_color_before.Text = "Color";
            // 
            // lbl_color_after
            // 
            this.lbl_color_after.AutoSize = true;
            this.lbl_color_after.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_color_after.Location = new System.Drawing.Point(392, 256);
            this.lbl_color_after.Name = "lbl_color_after";
            this.lbl_color_after.Size = new System.Drawing.Size(47, 15);
            this.lbl_color_after.TabIndex = 17;
            this.lbl_color_after.Text = "Color";
            // 
            // lbl_z_after
            // 
            this.lbl_z_after.AutoSize = true;
            this.lbl_z_after.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_z_after.Location = new System.Drawing.Point(392, 197);
            this.lbl_z_after.Name = "lbl_z_after";
            this.lbl_z_after.Size = new System.Drawing.Size(29, 15);
            this.lbl_z_after.TabIndex = 16;
            this.lbl_z_after.Text = "Z :";
            // 
            // lbl_y_after
            // 
            this.lbl_y_after.AutoSize = true;
            this.lbl_y_after.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_y_after.Location = new System.Drawing.Point(392, 139);
            this.lbl_y_after.Name = "lbl_y_after";
            this.lbl_y_after.Size = new System.Drawing.Size(28, 15);
            this.lbl_y_after.TabIndex = 15;
            this.lbl_y_after.Text = "Y :";
            // 
            // lbl_x_after
            // 
            this.lbl_x_after.AutoSize = true;
            this.lbl_x_after.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_x_after.Location = new System.Drawing.Point(392, 87);
            this.lbl_x_after.Name = "lbl_x_after";
            this.lbl_x_after.Size = new System.Drawing.Size(29, 15);
            this.lbl_x_after.TabIndex = 14;
            this.lbl_x_after.Text = "X :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label10.Location = new System.Drawing.Point(421, 37);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(128, 17);
            this.label10.TabIndex = 13;
            this.label10.Text = "현재 좌표 정보";
            // 
            // txt_color_after
            // 
            this.txt_color_after.BackColor = System.Drawing.Color.MistyRose;
            this.txt_color_after.Location = new System.Drawing.Point(478, 256);
            this.txt_color_after.Name = "txt_color_after";
            this.txt_color_after.Size = new System.Drawing.Size(100, 25);
            this.txt_color_after.TabIndex = 12;
            // 
            // txt_z_after
            // 
            this.txt_z_after.BackColor = System.Drawing.Color.MistyRose;
            this.txt_z_after.Location = new System.Drawing.Point(478, 192);
            this.txt_z_after.Name = "txt_z_after";
            this.txt_z_after.Size = new System.Drawing.Size(100, 25);
            this.txt_z_after.TabIndex = 11;
            // 
            // txt_y_after
            // 
            this.txt_y_after.BackColor = System.Drawing.Color.MistyRose;
            this.txt_y_after.Location = new System.Drawing.Point(478, 134);
            this.txt_y_after.Name = "txt_y_after";
            this.txt_y_after.Size = new System.Drawing.Size(100, 25);
            this.txt_y_after.TabIndex = 10;
            // 
            // txt_x_after
            // 
            this.txt_x_after.BackColor = System.Drawing.Color.MistyRose;
            this.txt_x_after.Location = new System.Drawing.Point(478, 82);
            this.txt_x_after.Name = "txt_x_after";
            this.txt_x_after.Size = new System.Drawing.Size(100, 25);
            this.txt_x_after.TabIndex = 9;
            // 
            // btn_x
            // 
            this.btn_x.BackColor = System.Drawing.Color.Salmon;
            this.btn_x.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_x.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_x.Location = new System.Drawing.Point(297, 82);
            this.btn_x.Name = "btn_x";
            this.btn_x.Size = new System.Drawing.Size(41, 25);
            this.btn_x.TabIndex = 18;
            this.btn_x.Text = ">>";
            this.btn_x.UseVisualStyleBackColor = false;
            this.btn_x.Click += new System.EventHandler(this.btn_x_Click);
            // 
            // btn_y
            // 
            this.btn_y.BackColor = System.Drawing.Color.Salmon;
            this.btn_y.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_y.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_y.Location = new System.Drawing.Point(297, 134);
            this.btn_y.Name = "btn_y";
            this.btn_y.Size = new System.Drawing.Size(41, 25);
            this.btn_y.TabIndex = 19;
            this.btn_y.Text = ">>";
            this.btn_y.UseVisualStyleBackColor = false;
            this.btn_y.Click += new System.EventHandler(this.btn_y_Click);
            // 
            // btn_z
            // 
            this.btn_z.BackColor = System.Drawing.Color.Salmon;
            this.btn_z.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_z.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_z.Location = new System.Drawing.Point(297, 190);
            this.btn_z.Name = "btn_z";
            this.btn_z.Size = new System.Drawing.Size(41, 25);
            this.btn_z.TabIndex = 20;
            this.btn_z.Text = ">>";
            this.btn_z.UseVisualStyleBackColor = false;
            this.btn_z.Click += new System.EventHandler(this.btn_z_Click);
            // 
            // btn_color
            // 
            this.btn_color.BackColor = System.Drawing.Color.Salmon;
            this.btn_color.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_color.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_color.Location = new System.Drawing.Point(297, 251);
            this.btn_color.Name = "btn_color";
            this.btn_color.Size = new System.Drawing.Size(41, 25);
            this.btn_color.TabIndex = 21;
            this.btn_color.Text = ">>";
            this.btn_color.UseVisualStyleBackColor = false;
            this.btn_color.Click += new System.EventHandler(this.btn_color_Click);
            // 
            // btn_create_obj
            // 
            this.btn_create_obj.BackColor = System.Drawing.Color.LightCoral;
            this.btn_create_obj.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_create_obj.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_create_obj.Location = new System.Drawing.Point(116, 324);
            this.btn_create_obj.Name = "btn_create_obj";
            this.btn_create_obj.Size = new System.Drawing.Size(108, 34);
            this.btn_create_obj.TabIndex = 22;
            this.btn_create_obj.Text = "객체 생성";
            this.btn_create_obj.UseVisualStyleBackColor = false;
            this.btn_create_obj.Click += new System.EventHandler(this.btn_create_obj_Click);
            // 
            // btn_MoveTo
            // 
            this.btn_MoveTo.BackColor = System.Drawing.Color.LightCoral;
            this.btn_MoveTo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_MoveTo.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_MoveTo.Location = new System.Drawing.Point(280, 324);
            this.btn_MoveTo.Name = "btn_MoveTo";
            this.btn_MoveTo.Size = new System.Drawing.Size(108, 34);
            this.btn_MoveTo.TabIndex = 23;
            this.btn_MoveTo.Text = "변경";
            this.btn_MoveTo.UseVisualStyleBackColor = false;
            this.btn_MoveTo.Click += new System.EventHandler(this.btn_MoveTo_Click);
            // 
            // btn_MoveBy
            // 
            this.btn_MoveBy.BackColor = System.Drawing.Color.LightCoral;
            this.btn_MoveBy.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_MoveBy.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_MoveBy.Location = new System.Drawing.Point(441, 324);
            this.btn_MoveBy.Name = "btn_MoveBy";
            this.btn_MoveBy.Size = new System.Drawing.Size(108, 34);
            this.btn_MoveBy.TabIndex = 24;
            this.btn_MoveBy.Text = "이동";
            this.btn_MoveBy.UseVisualStyleBackColor = false;
            this.btn_MoveBy.Click += new System.EventHandler(this.btn_MoveBy_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Snow;
            this.ClientSize = new System.Drawing.Size(681, 402);
            this.Controls.Add(this.btn_MoveBy);
            this.Controls.Add(this.btn_MoveTo);
            this.Controls.Add(this.btn_create_obj);
            this.Controls.Add(this.btn_color);
            this.Controls.Add(this.btn_z);
            this.Controls.Add(this.btn_y);
            this.Controls.Add(this.btn_x);
            this.Controls.Add(this.lbl_color_after);
            this.Controls.Add(this.lbl_z_after);
            this.Controls.Add(this.lbl_y_after);
            this.Controls.Add(this.lbl_x_after);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txt_color_after);
            this.Controls.Add(this.txt_z_after);
            this.Controls.Add(this.txt_y_after);
            this.Controls.Add(this.txt_x_after);
            this.Controls.Add(this.lbl_color_before);
            this.Controls.Add(this.lbl_z_before);
            this.Controls.Add(this.lbl_y_before);
            this.Controls.Add(this.lbl_x_before);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_color_before);
            this.Controls.Add(this.txt_z_before);
            this.Controls.Add(this.txt_y_before);
            this.Controls.Add(this.txt_x_before);
            this.Name = "Form1";
            this.Text = "좌표이동";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_x_before;
        private System.Windows.Forms.TextBox txt_y_before;
        private System.Windows.Forms.TextBox txt_z_before;
        private System.Windows.Forms.TextBox txt_color_before;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_x_before;
        private System.Windows.Forms.Label lbl_y_before;
        private System.Windows.Forms.Label lbl_z_before;
        private System.Windows.Forms.Label lbl_color_before;
        private System.Windows.Forms.Label lbl_color_after;
        private System.Windows.Forms.Label lbl_z_after;
        private System.Windows.Forms.Label lbl_y_after;
        private System.Windows.Forms.Label lbl_x_after;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_color_after;
        private System.Windows.Forms.TextBox txt_z_after;
        private System.Windows.Forms.TextBox txt_y_after;
        private System.Windows.Forms.TextBox txt_x_after;
        private System.Windows.Forms.Button btn_x;
        private System.Windows.Forms.Button btn_y;
        private System.Windows.Forms.Button btn_z;
        private System.Windows.Forms.Button btn_color;
        private System.Windows.Forms.Button btn_create_obj;
        private System.Windows.Forms.Button btn_MoveTo;
        private System.Windows.Forms.Button btn_MoveBy;
    }
}

