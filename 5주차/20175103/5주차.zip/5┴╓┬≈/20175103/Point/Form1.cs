﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// 프로그램명: Point
/// 프로그램 설명: 정수와 실수를 표현할 수 있는 범용 클래스이고 Point 클래스 객체를 생성 사용하는 윈도우 프로그램이다.
/// 작성일: 2019.03.28(목)
/// 학번, 학과: 20175103, 빅데이터전공
/// 작성자: 강보경
/// </summary>
namespace Point
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Point<object> pob;
        // 생성하는 메서드를 호출한다.
        private void btn_create_obj_Click(object sender, EventArgs e)
        {
            double value_x = Convert.ToDouble(txt_x.Text);
            double value_y = Convert.ToDouble(txt_y.Text);
            /* 형식 별로 다르게 나오도록 설정해 주었다. */
            if (value_x - (int)value_x == 0 && value_y - (int)value_y == 0)
            {
                pob = new Point<object>((int)value_x, (int)value_y);
                txt_obj_info.Text = pob.ToString();

            }
            else if (value_x - (int)value_x != 0 && value_y - (int)value_y != 0)
            {
                pob = new Point<object>(value_x, value_y);
                txt_obj_info.Text = pob.ToString();

            }
            else if (value_x - (int)value_x != 0 && value_y - (int)value_y == 0)
            {
                pob = new Point<object>(value_x, (int)value_y);
                txt_obj_info.Text = pob.ToString();
            }
            else
            {
                pob =  new Point<object>((int)value_x, value_y);
                txt_obj_info.Text = pob.ToString();
            }
        }
        // 변경할 값을 매개변수로 입력 받으면 저장하는 메서드를 호출한다.
        private void btn_change_location_Click(object sender, EventArgs e)
        {
            double value_x = Convert.ToDouble(txt_x.Text);
            double value_y = Convert.ToDouble(txt_y.Text);

            /* 형식 별로 다르게 나오도록 설정해 주었다. */
            if (value_x - (int)value_x == 0 && value_y - (int)value_y == 0)
            {
                pob.MoveTo((int)value_x, (int)value_y);
                txt_obj_info.Text = pob.ToString();

            }
            else if (value_x - (int)value_x != 0 && value_y - (int)value_y != 0)
            {
                pob.MoveTo(value_x, value_y);
                txt_obj_info.Text = pob.ToString();

            }else if (value_x - (int)value_x != 0 && value_y - (int)value_y == 0)
            {
                pob.MoveTo( value_x, (int)value_y);
                txt_obj_info.Text = pob.ToString();
            }
            else
            {
                pob.MoveTo((int)value_x, value_y);
                txt_obj_info.Text = pob.ToString();
            }
        }
        
    }
}
