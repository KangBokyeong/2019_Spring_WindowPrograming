﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Point
{
    class Point<TempType>
    {
        private TempType x;  // x좌표 값
        private TempType y;  // y좌표 값

        // 생성자, 매개변수 x,y 값으로 맴버변수를 초기화
        // 객체생성(범용으로)
        public Point (TempType x, TempType y)
        {
            this.x = x;
            this.y = y;
        }

        // 좌표 변경 메서드
        public void MoveTo(TempType x, TempType y)
        {
            this.x = x;
            this.y = y;
        }

        /* x,y의 좌표정보를 문자열로 제공하기위한 ToString() 메서드 재정의 */
        public override string ToString()
        {
            return "x: " + x + ", y: " + y;
        }

    }
}
