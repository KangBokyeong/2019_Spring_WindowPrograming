﻿namespace Point
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_obj_info = new System.Windows.Forms.TextBox();
            this.lbl_obj_info = new System.Windows.Forms.Label();
            this.txt_y = new System.Windows.Forms.TextBox();
            this.lbl_y = new System.Windows.Forms.Label();
            this.txt_x = new System.Windows.Forms.TextBox();
            this.btn_change_location = new System.Windows.Forms.Button();
            this.btn_create_obj = new System.Windows.Forms.Button();
            this.lbl_x = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_obj_info
            // 
            this.txt_obj_info.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txt_obj_info.Location = new System.Drawing.Point(116, 211);
            this.txt_obj_info.Name = "txt_obj_info";
            this.txt_obj_info.Size = new System.Drawing.Size(300, 25);
            this.txt_obj_info.TabIndex = 17;
            // 
            // lbl_obj_info
            // 
            this.lbl_obj_info.AutoSize = true;
            this.lbl_obj_info.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_obj_info.Location = new System.Drawing.Point(43, 215);
            this.lbl_obj_info.Name = "lbl_obj_info";
            this.lbl_obj_info.Size = new System.Drawing.Size(71, 15);
            this.lbl_obj_info.TabIndex = 16;
            this.lbl_obj_info.Text = "객체정보";
            // 
            // txt_y
            // 
            this.txt_y.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txt_y.Location = new System.Drawing.Point(276, 75);
            this.txt_y.Name = "txt_y";
            this.txt_y.Size = new System.Drawing.Size(100, 25);
            this.txt_y.TabIndex = 15;
            // 
            // lbl_y
            // 
            this.lbl_y.AutoSize = true;
            this.lbl_y.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_y.Location = new System.Drawing.Point(309, 39);
            this.lbl_y.Name = "lbl_y";
            this.lbl_y.Size = new System.Drawing.Size(37, 17);
            this.lbl_y.TabIndex = 14;
            this.lbl_y.Text = "Y값";
            // 
            // txt_x
            // 
            this.txt_x.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txt_x.Location = new System.Drawing.Point(86, 75);
            this.txt_x.Name = "txt_x";
            this.txt_x.Size = new System.Drawing.Size(100, 25);
            this.txt_x.TabIndex = 13;
            // 
            // btn_change_location
            // 
            this.btn_change_location.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btn_change_location.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_change_location.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_change_location.Location = new System.Drawing.Point(244, 134);
            this.btn_change_location.Name = "btn_change_location";
            this.btn_change_location.Size = new System.Drawing.Size(104, 34);
            this.btn_change_location.TabIndex = 11;
            this.btn_change_location.Text = "좌표변경";
            this.btn_change_location.UseVisualStyleBackColor = false;
            this.btn_change_location.Click += new System.EventHandler(this.btn_change_location_Click);
            // 
            // btn_create_obj
            // 
            this.btn_create_obj.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btn_create_obj.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_create_obj.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_create_obj.Location = new System.Drawing.Point(110, 134);
            this.btn_create_obj.Name = "btn_create_obj";
            this.btn_create_obj.Size = new System.Drawing.Size(104, 34);
            this.btn_create_obj.TabIndex = 10;
            this.btn_create_obj.Text = "객체생성";
            this.btn_create_obj.UseVisualStyleBackColor = false;
            this.btn_create_obj.Click += new System.EventHandler(this.btn_create_obj_Click);
            // 
            // lbl_x
            // 
            this.lbl_x.AutoSize = true;
            this.lbl_x.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_x.Location = new System.Drawing.Point(122, 39);
            this.lbl_x.Name = "lbl_x";
            this.lbl_x.Size = new System.Drawing.Size(38, 17);
            this.lbl_x.TabIndex = 9;
            this.lbl_x.Text = "X값";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(464, 286);
            this.Controls.Add(this.txt_obj_info);
            this.Controls.Add(this.lbl_obj_info);
            this.Controls.Add(this.txt_y);
            this.Controls.Add(this.lbl_y);
            this.Controls.Add(this.txt_x);
            this.Controls.Add(this.btn_change_location);
            this.Controls.Add(this.btn_create_obj);
            this.Controls.Add(this.lbl_x);
            this.Name = "Form1";
            this.Text = "Point";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_obj_info;
        private System.Windows.Forms.Label lbl_obj_info;
        private System.Windows.Forms.TextBox txt_y;
        private System.Windows.Forms.Label lbl_y;
        private System.Windows.Forms.TextBox txt_x;
        private System.Windows.Forms.Button btn_change_location;
        private System.Windows.Forms.Button btn_create_obj;
        private System.Windows.Forms.Label lbl_x;
    }
}

