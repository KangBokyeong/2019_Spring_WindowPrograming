﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookInfoWindowApp
{
    class Book
    {
        // 멤버변수
        string title;   // 책 제목
        string author;  // 책 저자
        int page;    // 쪽 수
        string ISBN;    // 국제표준도서번호 
        string publisher;   // 출판사
        
        // 생성자
        public Book(string title, string author, int page, string ISBN, string publisher)
        {
            this.title = title;
            this.author = author;
            this.page = page;
            this.ISBN = ISBN;
            this.publisher = publisher;
        }
        // title에 대한 메서드
        public string getTitle()
        {
            return title;
        }
        public void setTitle(string t)
        {
            title = t;
        }
        // Book 의 정보를 출력하기 위한 ToString()메소드 재정의
        public override string ToString()
        {
            return "제목: " + getTitle() + " / 저자: " + author + " / 쪽 수: " + page  + "페이지 / ISBN: " + ISBN + "/ 출판사: " + publisher;
        }

    }
}
