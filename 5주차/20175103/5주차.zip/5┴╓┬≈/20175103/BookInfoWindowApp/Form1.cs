﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// 프로그램명: BookInfoWindowApp
/// 프로그램 설명: 책의 정보를 저장하여 저장된 정보를 출력하는 윈도우 프로그램이다(단, 정보는 최신에 저장한 정보 하나만 저장된다.).
/// 작성일: 2019.03.28(목)
/// 학번, 학과: 20175103, 빅데이터전공
/// 작성자: 강보경
/// </summary>
namespace BookInfoWindowApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Book book;
        // 저장
        private void btn_save_Click(object sender, EventArgs e)
        {
            book = new Book(txt_title.Text, txt_author.Text, Convert.ToInt32(txt_page.Text), txt_ISBN.Text, txt_publisher.Text);
            // 초기화
            txt_title.Text = txt_author.Text = txt_page.Text = txt_ISBN.Text = txt_publisher.Text = "";
        }
        // 출력
        private void btn_print_Click(object sender, EventArgs e)
        {
            txt_print.Text = book.ToString();
        }
    }
}
