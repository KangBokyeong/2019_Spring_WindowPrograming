﻿namespace BookInfoWindowApp
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_title = new System.Windows.Forms.Label();
            this.lbl_author = new System.Windows.Forms.Label();
            this.lbl_page = new System.Windows.Forms.Label();
            this.lbl_ISBN = new System.Windows.Forms.Label();
            this.lbl_publisher = new System.Windows.Forms.Label();
            this.txt_title = new System.Windows.Forms.TextBox();
            this.txt_author = new System.Windows.Forms.TextBox();
            this.txt_page = new System.Windows.Forms.TextBox();
            this.txt_ISBN = new System.Windows.Forms.TextBox();
            this.txt_publisher = new System.Windows.Forms.TextBox();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_print = new System.Windows.Forms.Button();
            this.txt_print = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_title
            // 
            this.lbl_title.AutoSize = true;
            this.lbl_title.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_title.Location = new System.Drawing.Point(117, 60);
            this.lbl_title.Name = "lbl_title";
            this.lbl_title.Size = new System.Drawing.Size(61, 15);
            this.lbl_title.TabIndex = 0;
            this.lbl_title.Text = "책 제목";
            // 
            // lbl_author
            // 
            this.lbl_author.AutoSize = true;
            this.lbl_author.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_author.Location = new System.Drawing.Point(117, 107);
            this.lbl_author.Name = "lbl_author";
            this.lbl_author.Size = new System.Drawing.Size(61, 15);
            this.lbl_author.TabIndex = 1;
            this.lbl_author.Text = "책 저자";
            // 
            // lbl_page
            // 
            this.lbl_page.AutoSize = true;
            this.lbl_page.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_page.Location = new System.Drawing.Point(117, 148);
            this.lbl_page.Name = "lbl_page";
            this.lbl_page.Size = new System.Drawing.Size(45, 15);
            this.lbl_page.TabIndex = 2;
            this.lbl_page.Text = "쪽 수";
            // 
            // lbl_ISBN
            // 
            this.lbl_ISBN.AutoSize = true;
            this.lbl_ISBN.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_ISBN.Location = new System.Drawing.Point(117, 192);
            this.lbl_ISBN.Name = "lbl_ISBN";
            this.lbl_ISBN.Size = new System.Drawing.Size(135, 15);
            this.lbl_ISBN.TabIndex = 3;
            this.lbl_ISBN.Text = "국제표준도서번호";
            // 
            // lbl_publisher
            // 
            this.lbl_publisher.AutoSize = true;
            this.lbl_publisher.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_publisher.Location = new System.Drawing.Point(117, 235);
            this.lbl_publisher.Name = "lbl_publisher";
            this.lbl_publisher.Size = new System.Drawing.Size(55, 15);
            this.lbl_publisher.TabIndex = 4;
            this.lbl_publisher.Text = "출판사";
            // 
            // txt_title
            // 
            this.txt_title.BackColor = System.Drawing.Color.FloralWhite;
            this.txt_title.Location = new System.Drawing.Point(293, 54);
            this.txt_title.Name = "txt_title";
            this.txt_title.Size = new System.Drawing.Size(163, 25);
            this.txt_title.TabIndex = 5;
            // 
            // txt_author
            // 
            this.txt_author.BackColor = System.Drawing.Color.FloralWhite;
            this.txt_author.Location = new System.Drawing.Point(293, 102);
            this.txt_author.Name = "txt_author";
            this.txt_author.Size = new System.Drawing.Size(163, 25);
            this.txt_author.TabIndex = 6;
            // 
            // txt_page
            // 
            this.txt_page.BackColor = System.Drawing.Color.FloralWhite;
            this.txt_page.Location = new System.Drawing.Point(293, 143);
            this.txt_page.Name = "txt_page";
            this.txt_page.Size = new System.Drawing.Size(67, 25);
            this.txt_page.TabIndex = 7;
            // 
            // txt_ISBN
            // 
            this.txt_ISBN.BackColor = System.Drawing.Color.FloralWhite;
            this.txt_ISBN.Location = new System.Drawing.Point(293, 187);
            this.txt_ISBN.Name = "txt_ISBN";
            this.txt_ISBN.Size = new System.Drawing.Size(100, 25);
            this.txt_ISBN.TabIndex = 8;
            // 
            // txt_publisher
            // 
            this.txt_publisher.BackColor = System.Drawing.Color.FloralWhite;
            this.txt_publisher.Location = new System.Drawing.Point(293, 230);
            this.txt_publisher.Name = "txt_publisher";
            this.txt_publisher.Size = new System.Drawing.Size(133, 25);
            this.txt_publisher.TabIndex = 9;
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.Gold;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_save.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_save.Location = new System.Drawing.Point(139, 278);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(121, 35);
            this.btn_save.TabIndex = 10;
            this.btn_save.Text = "저장";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_print
            // 
            this.btn_print.BackColor = System.Drawing.Color.Gold;
            this.btn_print.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_print.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_print.Location = new System.Drawing.Point(304, 278);
            this.btn_print.Name = "btn_print";
            this.btn_print.Size = new System.Drawing.Size(121, 35);
            this.btn_print.TabIndex = 11;
            this.btn_print.Text = "출력";
            this.btn_print.UseVisualStyleBackColor = false;
            this.btn_print.Click += new System.EventHandler(this.btn_print_Click);
            // 
            // txt_print
            // 
            this.txt_print.BackColor = System.Drawing.Color.OldLace;
            this.txt_print.Location = new System.Drawing.Point(34, 332);
            this.txt_print.Multiline = true;
            this.txt_print.Name = "txt_print";
            this.txt_print.Size = new System.Drawing.Size(506, 79);
            this.txt_print.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Khaki;
            this.ClientSize = new System.Drawing.Size(565, 436);
            this.Controls.Add(this.txt_print);
            this.Controls.Add(this.btn_print);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.txt_publisher);
            this.Controls.Add(this.txt_ISBN);
            this.Controls.Add(this.txt_page);
            this.Controls.Add(this.txt_author);
            this.Controls.Add(this.txt_title);
            this.Controls.Add(this.lbl_publisher);
            this.Controls.Add(this.lbl_ISBN);
            this.Controls.Add(this.lbl_page);
            this.Controls.Add(this.lbl_author);
            this.Controls.Add(this.lbl_title);
            this.Name = "Form1";
            this.Text = "책 정보 저장";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_title;
        private System.Windows.Forms.Label lbl_author;
        private System.Windows.Forms.Label lbl_page;
        private System.Windows.Forms.Label lbl_ISBN;
        private System.Windows.Forms.Label lbl_publisher;
        private System.Windows.Forms.TextBox txt_title;
        private System.Windows.Forms.TextBox txt_author;
        private System.Windows.Forms.TextBox txt_page;
        private System.Windows.Forms.TextBox txt_ISBN;
        private System.Windows.Forms.TextBox txt_publisher;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_print;
        private System.Windows.Forms.TextBox txt_print;
    }
}

