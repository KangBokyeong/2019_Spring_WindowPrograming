﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// 프로그램명: MouseEventTest
/// 프로그램 설명: 마우스 및 키보드 입력에 대한 이벤트와 폼에 대한 정보를 각각 메시지 박스로 출력하는 윈도우 프로그램이다.
/// 작성일: 2019.04.11(목)
/// 학번, 학과: 20175103, 빅데이터전공
/// 작성자: 강보경
/// </summary>
namespace MouseEventTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void FormEvent(object sender, EventArgs e)
        {
            string msg = "Form Size : Width = " + this.Size.Width + ", Height = " + this.Size.Height;
            MessageBox.Show(msg, "FormLoad Event");
        }

        private void FormMouseMove(object sender, MouseEventArgs e)
        {
            lblOut.Text = "마우스위치: x =" + e.X + ", y = " + e.Y;
        }

        private void FormMouseClick(object sender, MouseEventArgs e)
        {
            MessageBox.Show("버튼:" + e.Button.ToString(), "MouseClick Event");
        }

        private void FormKeyPress(object sender, KeyPressEventArgs e)
        {
            MessageBox.Show("KeyChar:" + e.KeyChar, "KeyPress Event");
        }

        private void FormKeyDown(object sender, KeyEventArgs e)
        {
            MessageBox.Show("KeyCode:" + e.KeyCode, "KeyDown Event");
        }
    }
}
