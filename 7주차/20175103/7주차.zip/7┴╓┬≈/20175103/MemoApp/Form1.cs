﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// 프로그램명: MemoApp
/// 프로그램 설명: 간단하게 메모를 하여 종료까지만 하는 윈도우 프로그램이다.(메모에 대한 내용은 저장되지 않는다.)
/// 작성일: 2019.04.11(목)
/// 학번, 학과: 20175103, 빅데이터전공
/// 작성자: 강보경
/// </summary>
namespace MemoApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (txtMemo.Text != "") {
                if (DialogResult.No == MessageBox.Show("텍스트 박스에 내용이 있습니다.종료하시겠습니까", "알림", MessageBoxButtons.YesNo))
                { 
                        e.Cancel = true;
                }
            
            }
        }
        
        private void btnEnd_Click(object sender, EventArgs e)
        {
                Close();
        }
    }
}
