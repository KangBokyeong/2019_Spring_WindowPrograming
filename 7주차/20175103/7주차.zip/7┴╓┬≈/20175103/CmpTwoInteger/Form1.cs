﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// 프로그램명: CmpTwoInteger
/// 프로그램 설명: 두 정수를 입력하여 비교 결과를 출력해주는 윈도우 프로그램이다. (정수가 아닌 다른 값이나 입력을 아예 하지 않았을 경우에는 오류 메시지 박스가 출력된다.)
/// 작성일: 2019.04.11(목)
/// 학번, 학과: 20175103, 빅데이터전공
/// 작성자: 강보경
/// </summary>
namespace CmpTwoInteger
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCmp_Click(object sender, EventArgs e)
        {
            int i = 0;
            try
            {
                if (txtInt1.Text == "" || txtInt2.Text == "")
                {
                    throw new UserException("입력을 하지 않았습니다.");
                }else if (!(int.TryParse(txtInt1.Text, out i)) || !(int.TryParse(txtInt2.Text, out i)))
                {
                    throw new FormatException();
                }
                if (Convert.ToInt32(txtInt1.Text) < Convert.ToInt32(txtInt2.Text))
                {
                    lblResult.Text = txtInt1.Text + " < " + txtInt2.Text;
                }
                else if (Convert.ToInt32(txtInt1.Text) > Convert.ToInt32(txtInt2.Text))
                {
                    lblResult.Text = txtInt1.Text + " > " + txtInt2.Text;
                } else
                {
                    lblResult.Text = txtInt1.Text + " = " + txtInt2.Text;
                }

            }
            catch (UserException ue)
            {
                MessageBox.Show(ue.Message);
            }
            catch (FormatException fe)
            {
                MessageBox.Show(fe.Message);
            }
        }
    }
}
