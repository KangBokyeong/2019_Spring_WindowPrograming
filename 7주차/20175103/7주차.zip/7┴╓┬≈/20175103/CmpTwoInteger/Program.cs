﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CmpTwoInteger
{
    static class Program
    {
        /// <summary>
        /// 해당 응용 프로그램의 주 진입점입니다.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
    class UserException : ApplicationException
    {
        // 메시지를 입력 받기 위한 변수
        string msg;
        // 오류 메히지 생성자
        public UserException(string msg) : base(msg)
        {
            // 부모에서 처리해 주는 것으로 함.
        }
    }
}
