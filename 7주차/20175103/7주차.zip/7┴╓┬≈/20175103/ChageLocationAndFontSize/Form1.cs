﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// 프로그램명: ChageLocationAndFontSize
/// 프로그램 설명: 버튼 클릭 이벤트를 통해 라벨의 위치 및 크기를 변경시키는 윈도우 프로그램이다.
/// 작성일: 2019.04.11(목)
/// 학번, 학과: 20175103, 빅데이터전공
/// 작성자: 강보경
/// </summary>
namespace ChageLocationAndFontSize
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // 아래로 이동
        private void btnDown_Click(object sender, EventArgs e)
        {
            lblMove.Location = new Point(lblMove.Location.X, lblMove.Location.Y + 1);
        }
        // 위로 이동
        private void btnUp_Click(object sender, EventArgs e)
        {
            lblMove.Location = new Point(lblMove.Location.X, lblMove.Location.Y - 1);
        }
        // 오른쪽으로 이동
        private void btnRight_Click(object sender, EventArgs e)
        {
            lblMove.Location = new Point(lblMove.Location.X + 1, lblMove.Location.Y);
        }
        // 왼쪽으로 이동
        private void btnLeft_Click(object sender, EventArgs e)
        {
            lblMove.Location = new Point(lblMove.Location.X - 1, lblMove.Location.Y);
        }
        // 오른쪽 위로 이동
        private void btnRightUp_Click(object sender, EventArgs e)
        {
            lblMove.Location = new Point(lblMove.Location.X + 1, lblMove.Location.Y - 1);
        }
        // 오른쪽 아래로 이동
        private void btnRightDown_Click(object sender, EventArgs e)
        {
            lblMove.Location = new Point(lblMove.Location.X + 1, lblMove.Location.Y + 1);
        }
        // 왼쪽 아래로 이동
        private void btnLeftDown_Click(object sender, EventArgs e)
        {
            lblMove.Location = new Point(lblMove.Location.X - 1 , lblMove.Location.Y + 1);
        }
        // 왼쪽 위로 이동
        private void btnLeftUp_Click(object sender, EventArgs e)
        {
            lblMove.Location = new Point(lblMove.Location.X - 1, lblMove.Location.Y - 1);
        }
        // 폰트 크기: 크게
        private void btnMkbig_Click(object sender, EventArgs e)
        {
            lblMove.Font = new Font("휴먼편지체", lblMove.Font.Size + 1);
        }
        // 폰트 크기: 작게
        private void btnMksmall_Click(object sender, EventArgs e)
        {
            lblMove.Font = new Font("휴먼편지체", lblMove.Font.Size - 1);
        }
    }
}
