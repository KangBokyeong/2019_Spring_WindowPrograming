﻿namespace ChageLocationAndFontSize
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUp = new System.Windows.Forms.Button();
            this.btnDown = new System.Windows.Forms.Button();
            this.btnLeft = new System.Windows.Forms.Button();
            this.btnRight = new System.Windows.Forms.Button();
            this.btnMkbig = new System.Windows.Forms.Button();
            this.btnMksmall = new System.Windows.Forms.Button();
            this.btnLeftUp = new System.Windows.Forms.Button();
            this.btnRightUp = new System.Windows.Forms.Button();
            this.btnLeftDown = new System.Windows.Forms.Button();
            this.btnRightDown = new System.Windows.Forms.Button();
            this.lblMove = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnUp
            // 
            this.btnUp.BackColor = System.Drawing.Color.Wheat;
            this.btnUp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUp.Font = new System.Drawing.Font("휴먼편지체", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUp.Location = new System.Drawing.Point(177, 332);
            this.btnUp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnUp.Name = "btnUp";
            this.btnUp.Size = new System.Drawing.Size(94, 31);
            this.btnUp.TabIndex = 0;
            this.btnUp.Text = "위";
            this.btnUp.UseVisualStyleBackColor = false;
            this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
            // 
            // btnDown
            // 
            this.btnDown.BackColor = System.Drawing.Color.Wheat;
            this.btnDown.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDown.Font = new System.Drawing.Font("휴먼편지체", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnDown.Location = new System.Drawing.Point(177, 410);
            this.btnDown.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDown.Name = "btnDown";
            this.btnDown.Size = new System.Drawing.Size(94, 31);
            this.btnDown.TabIndex = 1;
            this.btnDown.Text = "아래";
            this.btnDown.UseVisualStyleBackColor = false;
            this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
            // 
            // btnLeft
            // 
            this.btnLeft.BackColor = System.Drawing.Color.Wheat;
            this.btnLeft.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLeft.Font = new System.Drawing.Font("휴먼편지체", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnLeft.Location = new System.Drawing.Point(65, 371);
            this.btnLeft.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLeft.Name = "btnLeft";
            this.btnLeft.Size = new System.Drawing.Size(94, 31);
            this.btnLeft.TabIndex = 2;
            this.btnLeft.Text = "왼쪽";
            this.btnLeft.UseVisualStyleBackColor = false;
            this.btnLeft.Click += new System.EventHandler(this.btnLeft_Click);
            // 
            // btnRight
            // 
            this.btnRight.BackColor = System.Drawing.Color.Wheat;
            this.btnRight.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRight.Font = new System.Drawing.Font("휴먼편지체", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnRight.Location = new System.Drawing.Point(284, 371);
            this.btnRight.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRight.Name = "btnRight";
            this.btnRight.Size = new System.Drawing.Size(94, 31);
            this.btnRight.TabIndex = 3;
            this.btnRight.Text = "오른쪽";
            this.btnRight.UseVisualStyleBackColor = false;
            this.btnRight.Click += new System.EventHandler(this.btnRight_Click);
            // 
            // btnMkbig
            // 
            this.btnMkbig.BackColor = System.Drawing.Color.Cornsilk;
            this.btnMkbig.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMkbig.Font = new System.Drawing.Font("휴먼편지체", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnMkbig.Location = new System.Drawing.Point(487, 99);
            this.btnMkbig.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMkbig.Name = "btnMkbig";
            this.btnMkbig.Size = new System.Drawing.Size(94, 31);
            this.btnMkbig.TabIndex = 4;
            this.btnMkbig.Text = "크게";
            this.btnMkbig.UseVisualStyleBackColor = false;
            this.btnMkbig.Click += new System.EventHandler(this.btnMkbig_Click);
            // 
            // btnMksmall
            // 
            this.btnMksmall.BackColor = System.Drawing.Color.Cornsilk;
            this.btnMksmall.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMksmall.Font = new System.Drawing.Font("휴먼편지체", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnMksmall.Location = new System.Drawing.Point(487, 152);
            this.btnMksmall.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMksmall.Name = "btnMksmall";
            this.btnMksmall.Size = new System.Drawing.Size(94, 31);
            this.btnMksmall.TabIndex = 5;
            this.btnMksmall.Text = "작게";
            this.btnMksmall.UseVisualStyleBackColor = false;
            this.btnMksmall.Click += new System.EventHandler(this.btnMksmall_Click);
            // 
            // btnLeftUp
            // 
            this.btnLeftUp.BackColor = System.Drawing.Color.Wheat;
            this.btnLeftUp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLeftUp.Font = new System.Drawing.Font("휴먼편지체", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnLeftUp.Location = new System.Drawing.Point(114, 332);
            this.btnLeftUp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLeftUp.Name = "btnLeftUp";
            this.btnLeftUp.Size = new System.Drawing.Size(45, 31);
            this.btnLeftUp.TabIndex = 6;
            this.btnLeftUp.UseVisualStyleBackColor = false;
            this.btnLeftUp.Click += new System.EventHandler(this.btnLeftUp_Click);
            // 
            // btnRightUp
            // 
            this.btnRightUp.BackColor = System.Drawing.Color.Wheat;
            this.btnRightUp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRightUp.Font = new System.Drawing.Font("휴먼편지체", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnRightUp.Location = new System.Drawing.Point(284, 332);
            this.btnRightUp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRightUp.Name = "btnRightUp";
            this.btnRightUp.Size = new System.Drawing.Size(45, 31);
            this.btnRightUp.TabIndex = 7;
            this.btnRightUp.UseVisualStyleBackColor = false;
            this.btnRightUp.Click += new System.EventHandler(this.btnRightUp_Click);
            // 
            // btnLeftDown
            // 
            this.btnLeftDown.BackColor = System.Drawing.Color.Wheat;
            this.btnLeftDown.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLeftDown.Font = new System.Drawing.Font("휴먼편지체", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnLeftDown.Location = new System.Drawing.Point(114, 410);
            this.btnLeftDown.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLeftDown.Name = "btnLeftDown";
            this.btnLeftDown.Size = new System.Drawing.Size(45, 31);
            this.btnLeftDown.TabIndex = 8;
            this.btnLeftDown.UseVisualStyleBackColor = false;
            this.btnLeftDown.Click += new System.EventHandler(this.btnLeftDown_Click);
            // 
            // btnRightDown
            // 
            this.btnRightDown.BackColor = System.Drawing.Color.Wheat;
            this.btnRightDown.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRightDown.Font = new System.Drawing.Font("휴먼편지체", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnRightDown.Location = new System.Drawing.Point(284, 410);
            this.btnRightDown.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRightDown.Name = "btnRightDown";
            this.btnRightDown.Size = new System.Drawing.Size(45, 31);
            this.btnRightDown.TabIndex = 9;
            this.btnRightDown.UseVisualStyleBackColor = false;
            this.btnRightDown.Click += new System.EventHandler(this.btnRightDown_Click);
            // 
            // lblMove
            // 
            this.lblMove.AutoSize = true;
            this.lblMove.BackColor = System.Drawing.Color.DarkOrange;
            this.lblMove.Font = new System.Drawing.Font("휴먼편지체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblMove.Location = new System.Drawing.Point(183, 152);
            this.lblMove.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMove.Name = "lblMove";
            this.lblMove.Size = new System.Drawing.Size(73, 17);
            this.lblMove.TabIndex = 10;
            this.lblMove.Text = "움직이는 말";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PapayaWhip;
            this.ClientSize = new System.Drawing.Size(652, 496);
            this.Controls.Add(this.lblMove);
            this.Controls.Add(this.btnRightDown);
            this.Controls.Add(this.btnLeftDown);
            this.Controls.Add(this.btnRightUp);
            this.Controls.Add(this.btnLeftUp);
            this.Controls.Add(this.btnMksmall);
            this.Controls.Add(this.btnMkbig);
            this.Controls.Add(this.btnRight);
            this.Controls.Add(this.btnLeft);
            this.Controls.Add(this.btnDown);
            this.Controls.Add(this.btnUp);
            this.Font = new System.Drawing.Font("휴먼편지체", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "위치, 폰트 크기 변경";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUp;
        private System.Windows.Forms.Button btnDown;
        private System.Windows.Forms.Button btnLeft;
        private System.Windows.Forms.Button btnRight;
        private System.Windows.Forms.Button btnMkbig;
        private System.Windows.Forms.Button btnMksmall;
        private System.Windows.Forms.Button btnLeftUp;
        private System.Windows.Forms.Button btnRightUp;
        private System.Windows.Forms.Button btnLeftDown;
        private System.Windows.Forms.Button btnRightDown;
        private System.Windows.Forms.Label lblMove;
    }
}

