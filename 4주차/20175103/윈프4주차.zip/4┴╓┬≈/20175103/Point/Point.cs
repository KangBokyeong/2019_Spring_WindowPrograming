﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Point
{
    class Point
    {
        int x;  // x좌표 값
        int y;  // y좌표 값

        // 생성자, 매개변수 x,y 값으로 맴버변수를 초기화
        // 객체생성
        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        // 좌표 변경 메서드
        public void MoveTo(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        // 좌표 이동(입력 받은 만큼 변동해주기) 메서드
        public void MoveBy(int moveX, int moveY)
        {
            x = x + moveX;
            y = y + moveY;
        }
        // 문자열로 출력/ 출력 메서드
        public override string ToString()
        {
            return "x: " + x + ", y: " + y;
        }
    }
}
