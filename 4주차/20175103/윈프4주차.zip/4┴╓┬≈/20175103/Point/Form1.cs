﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// 프로그램명: Point
/// 프로그램 설명: 텍스트 박스에서 x, y의 좌표값을 입력 받아 출력및 변경하는 윈도우 프로그램이며, 이동은 입력 받은 만큼 변동한다. 
/// 작성일: 2019.03.21(목)
/// 학번, 학과: 20175103, 빅데이터전공
/// 작성자: 강보경
/// </summary>
namespace Point
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Point p;
        // 생성하는 메소드를 호출한다.
        private void btn_create_obj_Click(object sender, EventArgs e)
        {
            p = new Point(Convert.ToInt32(txt_x.Text), Convert.ToInt32(txt_y.Text));
            txt_obj_info.Text = p.ToString();
        }
        // 변경할 값을 매개변수로 입력 받으면 저장하는 메서드를 호출한다.
        private void btn_change_location_Click(object sender, EventArgs e)
        {
            p.MoveTo(Convert.ToInt32(txt_x.Text), Convert.ToInt32(txt_y.Text));
            txt_obj_info.Text = p.ToString();
        }
        // 값을 매개변수로 받은 만큼 이동하는 메서드를 호출해준다.
        private void btn_move_location_Click(object sender, EventArgs e)
        {
            p.MoveBy(Convert.ToInt32(txt_x.Text), Convert.ToInt32(txt_y.Text));
            txt_obj_info.Text = p.ToString();
        }

    }
}
