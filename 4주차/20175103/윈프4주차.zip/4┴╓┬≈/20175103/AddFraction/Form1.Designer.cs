﻿namespace AddFraction
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_calc = new System.Windows.Forms.Button();
            this.txt_denominator_res = new System.Windows.Forms.TextBox();
            this.txt_numerator_res = new System.Windows.Forms.TextBox();
            this.lbl_denominator_res = new System.Windows.Forms.Label();
            this.lbl_numerator_res = new System.Windows.Forms.Label();
            this.lbl_result = new System.Windows.Forms.Label();
            this.txt_denominator2 = new System.Windows.Forms.TextBox();
            this.txt_numerator2 = new System.Windows.Forms.TextBox();
            this.lbl_denominator2 = new System.Windows.Forms.Label();
            this.lbl_numerator2 = new System.Windows.Forms.Label();
            this.lbl_fraction2 = new System.Windows.Forms.Label();
            this.txt_denominator1 = new System.Windows.Forms.TextBox();
            this.txt_numerator1 = new System.Windows.Forms.TextBox();
            this.lbl_plus = new System.Windows.Forms.Label();
            this.lbl_denominator1 = new System.Windows.Forms.Label();
            this.lbl_numerator1 = new System.Windows.Forms.Label();
            this.lbl_fraction1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_calc
            // 
            this.btn_calc.BackColor = System.Drawing.Color.Green;
            this.btn_calc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_calc.Font = new System.Drawing.Font("굴림", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_calc.Location = new System.Drawing.Point(124, 187);
            this.btn_calc.Name = "btn_calc";
            this.btn_calc.Size = new System.Drawing.Size(54, 32);
            this.btn_calc.TabIndex = 33;
            this.btn_calc.Text = "=";
            this.btn_calc.UseVisualStyleBackColor = false;
            this.btn_calc.Click += new System.EventHandler(this.btn_calc_Click);
            // 
            // txt_denominator_res
            // 
            this.txt_denominator_res.BackColor = System.Drawing.Color.Honeydew;
            this.txt_denominator_res.Location = new System.Drawing.Point(365, 215);
            this.txt_denominator_res.Name = "txt_denominator_res";
            this.txt_denominator_res.Size = new System.Drawing.Size(100, 25);
            this.txt_denominator_res.TabIndex = 32;
            // 
            // txt_numerator_res
            // 
            this.txt_numerator_res.BackColor = System.Drawing.Color.Honeydew;
            this.txt_numerator_res.Location = new System.Drawing.Point(365, 182);
            this.txt_numerator_res.Name = "txt_numerator_res";
            this.txt_numerator_res.Size = new System.Drawing.Size(100, 25);
            this.txt_numerator_res.TabIndex = 31;
            // 
            // lbl_denominator_res
            // 
            this.lbl_denominator_res.AutoSize = true;
            this.lbl_denominator_res.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_denominator_res.Location = new System.Drawing.Point(300, 219);
            this.lbl_denominator_res.Name = "lbl_denominator_res";
            this.lbl_denominator_res.Size = new System.Drawing.Size(39, 15);
            this.lbl_denominator_res.TabIndex = 30;
            this.lbl_denominator_res.Text = "분모";
            // 
            // lbl_numerator_res
            // 
            this.lbl_numerator_res.AutoSize = true;
            this.lbl_numerator_res.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_numerator_res.Location = new System.Drawing.Point(300, 187);
            this.lbl_numerator_res.Name = "lbl_numerator_res";
            this.lbl_numerator_res.Size = new System.Drawing.Size(39, 15);
            this.lbl_numerator_res.TabIndex = 29;
            this.lbl_numerator_res.Text = "분자";
            // 
            // lbl_result
            // 
            this.lbl_result.AutoSize = true;
            this.lbl_result.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_result.Location = new System.Drawing.Point(370, 151);
            this.lbl_result.Name = "lbl_result";
            this.lbl_result.Size = new System.Drawing.Size(44, 17);
            this.lbl_result.TabIndex = 28;
            this.lbl_result.Text = "결과";
            // 
            // txt_denominator2
            // 
            this.txt_denominator2.BackColor = System.Drawing.Color.Honeydew;
            this.txt_denominator2.Location = new System.Drawing.Point(545, 99);
            this.txt_denominator2.Name = "txt_denominator2";
            this.txt_denominator2.Size = new System.Drawing.Size(100, 25);
            this.txt_denominator2.TabIndex = 27;
            // 
            // txt_numerator2
            // 
            this.txt_numerator2.BackColor = System.Drawing.Color.Honeydew;
            this.txt_numerator2.Location = new System.Drawing.Point(545, 66);
            this.txt_numerator2.Name = "txt_numerator2";
            this.txt_numerator2.Size = new System.Drawing.Size(100, 25);
            this.txt_numerator2.TabIndex = 26;
            // 
            // lbl_denominator2
            // 
            this.lbl_denominator2.AutoSize = true;
            this.lbl_denominator2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_denominator2.Location = new System.Drawing.Point(480, 103);
            this.lbl_denominator2.Name = "lbl_denominator2";
            this.lbl_denominator2.Size = new System.Drawing.Size(39, 15);
            this.lbl_denominator2.TabIndex = 25;
            this.lbl_denominator2.Text = "분모";
            // 
            // lbl_numerator2
            // 
            this.lbl_numerator2.AutoSize = true;
            this.lbl_numerator2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_numerator2.Location = new System.Drawing.Point(480, 71);
            this.lbl_numerator2.Name = "lbl_numerator2";
            this.lbl_numerator2.Size = new System.Drawing.Size(39, 15);
            this.lbl_numerator2.TabIndex = 24;
            this.lbl_numerator2.Text = "분자";
            // 
            // lbl_fraction2
            // 
            this.lbl_fraction2.AutoSize = true;
            this.lbl_fraction2.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_fraction2.Location = new System.Drawing.Point(532, 30);
            this.lbl_fraction2.Name = "lbl_fraction2";
            this.lbl_fraction2.Size = new System.Drawing.Size(59, 17);
            this.lbl_fraction2.TabIndex = 23;
            this.lbl_fraction2.Text = "분수 2";
            // 
            // txt_denominator1
            // 
            this.txt_denominator1.BackColor = System.Drawing.Color.Honeydew;
            this.txt_denominator1.Location = new System.Drawing.Point(204, 100);
            this.txt_denominator1.Name = "txt_denominator1";
            this.txt_denominator1.Size = new System.Drawing.Size(100, 25);
            this.txt_denominator1.TabIndex = 22;
            // 
            // txt_numerator1
            // 
            this.txt_numerator1.BackColor = System.Drawing.Color.Honeydew;
            this.txt_numerator1.Location = new System.Drawing.Point(204, 67);
            this.txt_numerator1.Name = "txt_numerator1";
            this.txt_numerator1.Size = new System.Drawing.Size(100, 25);
            this.txt_numerator1.TabIndex = 21;
            // 
            // lbl_plus
            // 
            this.lbl_plus.AutoSize = true;
            this.lbl_plus.Font = new System.Drawing.Font("굴림", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_plus.Location = new System.Drawing.Point(379, 90);
            this.lbl_plus.Name = "lbl_plus";
            this.lbl_plus.Size = new System.Drawing.Size(19, 19);
            this.lbl_plus.TabIndex = 20;
            this.lbl_plus.Text = "+";
            // 
            // lbl_denominator1
            // 
            this.lbl_denominator1.AutoSize = true;
            this.lbl_denominator1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_denominator1.Location = new System.Drawing.Point(139, 104);
            this.lbl_denominator1.Name = "lbl_denominator1";
            this.lbl_denominator1.Size = new System.Drawing.Size(39, 15);
            this.lbl_denominator1.TabIndex = 19;
            this.lbl_denominator1.Text = "분모";
            // 
            // lbl_numerator1
            // 
            this.lbl_numerator1.AutoSize = true;
            this.lbl_numerator1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_numerator1.Location = new System.Drawing.Point(139, 72);
            this.lbl_numerator1.Name = "lbl_numerator1";
            this.lbl_numerator1.Size = new System.Drawing.Size(39, 15);
            this.lbl_numerator1.TabIndex = 18;
            this.lbl_numerator1.Text = "분자";
            // 
            // lbl_fraction1
            // 
            this.lbl_fraction1.AutoSize = true;
            this.lbl_fraction1.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_fraction1.Location = new System.Drawing.Point(192, 30);
            this.lbl_fraction1.Name = "lbl_fraction1";
            this.lbl_fraction1.Size = new System.Drawing.Size(59, 17);
            this.lbl_fraction1.TabIndex = 17;
            this.lbl_fraction1.Text = "분수 1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGreen;
            this.ClientSize = new System.Drawing.Size(800, 295);
            this.Controls.Add(this.btn_calc);
            this.Controls.Add(this.txt_denominator_res);
            this.Controls.Add(this.txt_numerator_res);
            this.Controls.Add(this.lbl_denominator_res);
            this.Controls.Add(this.lbl_numerator_res);
            this.Controls.Add(this.lbl_result);
            this.Controls.Add(this.txt_denominator2);
            this.Controls.Add(this.txt_numerator2);
            this.Controls.Add(this.lbl_denominator2);
            this.Controls.Add(this.lbl_numerator2);
            this.Controls.Add(this.lbl_fraction2);
            this.Controls.Add(this.txt_denominator1);
            this.Controls.Add(this.txt_numerator1);
            this.Controls.Add(this.lbl_plus);
            this.Controls.Add(this.lbl_denominator1);
            this.Controls.Add(this.lbl_numerator1);
            this.Controls.Add(this.lbl_fraction1);
            this.Name = "Form1";
            this.Text = "분수 계산";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_calc;
        private System.Windows.Forms.TextBox txt_denominator_res;
        private System.Windows.Forms.TextBox txt_numerator_res;
        private System.Windows.Forms.Label lbl_denominator_res;
        private System.Windows.Forms.Label lbl_numerator_res;
        private System.Windows.Forms.Label lbl_result;
        private System.Windows.Forms.TextBox txt_denominator2;
        private System.Windows.Forms.TextBox txt_numerator2;
        private System.Windows.Forms.Label lbl_denominator2;
        private System.Windows.Forms.Label lbl_numerator2;
        private System.Windows.Forms.Label lbl_fraction2;
        private System.Windows.Forms.TextBox txt_denominator1;
        private System.Windows.Forms.TextBox txt_numerator1;
        private System.Windows.Forms.Label lbl_plus;
        private System.Windows.Forms.Label lbl_denominator1;
        private System.Windows.Forms.Label lbl_numerator1;
        private System.Windows.Forms.Label lbl_fraction1;
    }
}

