﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// 프로그램명: AddFraction
/// 프로그램 설명: 분수 계산이 가능한 윈도우 프로그램이다.(클래스 이용)
/// 작성일: 2019.03.21(목)
/// 학번, 학과: 20175103, 빅데이터전공
/// 작성자: 강보경
/// </summary>
namespace AddFraction
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void btn_calc_Click(object sender, EventArgs e)
        {
            Fraction f1 = new Fraction(Convert.ToInt32(txt_numerator1.Text), Convert.ToInt32(txt_denominator1.Text));
            Fraction f2 = new Fraction(Convert.ToInt32(txt_numerator2.Text), Convert.ToInt32(txt_denominator2.Text));

            // 더하기 메서드 호출
            Fraction f3 = f1.Add(f2);

            // 텍스트박스에 출력 (분모, 분자를 각각 따로 호출하여 출력해줌.)
            txt_denominator_res.Text = Convert.ToString(f3.getDenominator());   // 분모
            txt_numerator_res.Text = Convert.ToString(f3.getNumerator());     // 분자

        }
    }
}
