﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AddFraction
{
    class Fraction
    {

        int numerator;      // 분자 필드
        int denominator;    // 분모 필드
        

        public Fraction(int numerator, int denominator)
        {
            this.numerator = numerator;
            this.denominator = denominator;
        }
        // 덧셈 메서드 (기준은 첫번째 분수, 매개변수로 받아온 것은 두번째 분수)
        public Fraction Add(Fraction f2) 
        {
            int tmp_numerator;      // 임시 분자 필드
            int tmp_denominator;    // 임시 분모 필드



            // 분모가 둘다 다를 경우 최대공약수를 찾고
            if (denominator != f2.denominator)
            {
                tmp_denominator = f2.denominator * denominator;  // 분모는 서로 곱해주기
                                                                // 첫번째 분수의 분자는 두번째 분수에 곱해준 값을 곱하고,
                                                                // 두번째 분수의 분자는 첫번째 분수에 곱해준 값을 곱하여 서로 더해준다.
                tmp_numerator = (f2.numerator * denominator) + (numerator * f2.denominator);
                
            }
            else
            {
                tmp_denominator = f2.denominator;         // 분모는 그대로 둘 다 같기에 아무거나 선택하여 저장한다.
                tmp_numerator = numerator + f2.numerator; // 분자끼리 더해주기
            }
            // 최대공약수를 구하여 최종적인 결과 반환
            int gcd = GCD(tmp_numerator, tmp_denominator);
            // 분자, 분모를 앞서 구해준 최대공약수로 나눠준다.
            tmp_numerator = tmp_numerator / gcd;
            tmp_denominator = tmp_denominator / gcd;
            // 새로운 객체 생성 후 반환
            Fraction f = new Fraction(tmp_numerator, tmp_denominator);
            return f;
        }
        // 분자 반환 메서드
        public int getNumerator()
        {
            return numerator;
        }
        // 분모 반환 메서드
        public int getDenominator()
        {
            return denominator;
        }

        // 최대공약수를 구해주는 메서드
        int GCD(int a, int b)
        {
            while (b != 0)
            {
                int temp = a % b;
                a = b;
                b = temp;
            }

            return a;
        }
    }



}
