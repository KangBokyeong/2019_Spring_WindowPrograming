﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contact
{
    class Contact
    {
        
        string name; // 이름
        int age; // 나이
        string company; // 직장
        string cellPhone; // 휴대폰
        string tel;     // 전화
        string mail;    // 메일
        
        // 생성자 (매개변수로 값을 받아오기)
        public Contact(string name, int age, string company, string cellPhone, string tel, string mail)
        {
            this.name = name;
            this.age = age;
            this.company = company;
            this.cellPhone = cellPhone;
            this.tel = tel;
            this.mail = mail;

        }
        // 문자열 출력해주는 메서드 
        public override string ToString()
        {
            return "이름 / 나이 / 직장 / 휴대폰 / 전화 / 메일" + Environment.NewLine + name + " / " + Convert.ToString(age) + " / " + company + " / " + cellPhone + " / " + tel + " / " + mail + Environment.NewLine;
        }

    }

}
