﻿namespace Contact
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_name = new System.Windows.Forms.Label();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.txt_age = new System.Windows.Forms.TextBox();
            this.lbl_age = new System.Windows.Forms.Label();
            this.txt_company = new System.Windows.Forms.TextBox();
            this.lbl_company = new System.Windows.Forms.Label();
            this.txt_cellPhone = new System.Windows.Forms.TextBox();
            this.lbl_cellPhone = new System.Windows.Forms.Label();
            this.txt_Tel = new System.Windows.Forms.TextBox();
            this.lbl_Tel = new System.Windows.Forms.Label();
            this.txt_mail = new System.Windows.Forms.TextBox();
            this.lbl_mail = new System.Windows.Forms.Label();
            this.txt_result = new System.Windows.Forms.TextBox();
            this.btn_create_obj = new System.Windows.Forms.Button();
            this.btn_print = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_name.Location = new System.Drawing.Point(56, 46);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(39, 15);
            this.lbl_name.TabIndex = 0;
            this.lbl_name.Text = "이름";
            // 
            // txt_name
            // 
            this.txt_name.BackColor = System.Drawing.Color.Ivory;
            this.txt_name.Location = new System.Drawing.Point(118, 41);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(117, 25);
            this.txt_name.TabIndex = 1;
            // 
            // txt_age
            // 
            this.txt_age.BackColor = System.Drawing.Color.Ivory;
            this.txt_age.Location = new System.Drawing.Point(118, 81);
            this.txt_age.Name = "txt_age";
            this.txt_age.Size = new System.Drawing.Size(46, 25);
            this.txt_age.TabIndex = 3;
            // 
            // lbl_age
            // 
            this.lbl_age.AutoSize = true;
            this.lbl_age.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_age.Location = new System.Drawing.Point(56, 86);
            this.lbl_age.Name = "lbl_age";
            this.lbl_age.Size = new System.Drawing.Size(39, 15);
            this.lbl_age.TabIndex = 2;
            this.lbl_age.Text = "나이";
            // 
            // txt_company
            // 
            this.txt_company.BackColor = System.Drawing.Color.Ivory;
            this.txt_company.Location = new System.Drawing.Point(118, 125);
            this.txt_company.Name = "txt_company";
            this.txt_company.Size = new System.Drawing.Size(285, 25);
            this.txt_company.TabIndex = 5;
            // 
            // lbl_company
            // 
            this.lbl_company.AutoSize = true;
            this.lbl_company.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_company.Location = new System.Drawing.Point(56, 130);
            this.lbl_company.Name = "lbl_company";
            this.lbl_company.Size = new System.Drawing.Size(39, 15);
            this.lbl_company.TabIndex = 4;
            this.lbl_company.Text = "직장";
            // 
            // txt_cellPhone
            // 
            this.txt_cellPhone.BackColor = System.Drawing.Color.Ivory;
            this.txt_cellPhone.Location = new System.Drawing.Point(118, 167);
            this.txt_cellPhone.Name = "txt_cellPhone";
            this.txt_cellPhone.Size = new System.Drawing.Size(193, 25);
            this.txt_cellPhone.TabIndex = 7;
            // 
            // lbl_cellPhone
            // 
            this.lbl_cellPhone.AutoSize = true;
            this.lbl_cellPhone.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_cellPhone.Location = new System.Drawing.Point(56, 172);
            this.lbl_cellPhone.Name = "lbl_cellPhone";
            this.lbl_cellPhone.Size = new System.Drawing.Size(55, 15);
            this.lbl_cellPhone.TabIndex = 6;
            this.lbl_cellPhone.Text = "휴대폰";
            // 
            // txt_Tel
            // 
            this.txt_Tel.BackColor = System.Drawing.Color.Ivory;
            this.txt_Tel.Location = new System.Drawing.Point(118, 207);
            this.txt_Tel.Name = "txt_Tel";
            this.txt_Tel.Size = new System.Drawing.Size(193, 25);
            this.txt_Tel.TabIndex = 9;
            // 
            // lbl_Tel
            // 
            this.lbl_Tel.AutoSize = true;
            this.lbl_Tel.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_Tel.Location = new System.Drawing.Point(56, 212);
            this.lbl_Tel.Name = "lbl_Tel";
            this.lbl_Tel.Size = new System.Drawing.Size(39, 15);
            this.lbl_Tel.TabIndex = 8;
            this.lbl_Tel.Text = "전화";
            // 
            // txt_mail
            // 
            this.txt_mail.BackColor = System.Drawing.Color.Ivory;
            this.txt_mail.Location = new System.Drawing.Point(118, 250);
            this.txt_mail.Name = "txt_mail";
            this.txt_mail.Size = new System.Drawing.Size(255, 25);
            this.txt_mail.TabIndex = 11;
            // 
            // lbl_mail
            // 
            this.lbl_mail.AutoSize = true;
            this.lbl_mail.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_mail.Location = new System.Drawing.Point(56, 255);
            this.lbl_mail.Name = "lbl_mail";
            this.lbl_mail.Size = new System.Drawing.Size(39, 15);
            this.lbl_mail.TabIndex = 10;
            this.lbl_mail.Text = "메일";
            // 
            // txt_result
            // 
            this.txt_result.BackColor = System.Drawing.Color.Ivory;
            this.txt_result.Location = new System.Drawing.Point(59, 352);
            this.txt_result.Multiline = true;
            this.txt_result.Name = "txt_result";
            this.txt_result.Size = new System.Drawing.Size(673, 72);
            this.txt_result.TabIndex = 12;
            // 
            // btn_create_obj
            // 
            this.btn_create_obj.BackColor = System.Drawing.Color.LemonChiffon;
            this.btn_create_obj.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_create_obj.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_create_obj.Location = new System.Drawing.Point(541, 137);
            this.btn_create_obj.Name = "btn_create_obj";
            this.btn_create_obj.Size = new System.Drawing.Size(126, 59);
            this.btn_create_obj.TabIndex = 13;
            this.btn_create_obj.Text = "객체생성";
            this.btn_create_obj.UseVisualStyleBackColor = false;
            this.btn_create_obj.Click += new System.EventHandler(this.btn_create_obj_Click);
            // 
            // btn_print
            // 
            this.btn_print.BackColor = System.Drawing.Color.LemonChiffon;
            this.btn_print.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_print.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_print.Location = new System.Drawing.Point(322, 295);
            this.btn_print.Name = "btn_print";
            this.btn_print.Size = new System.Drawing.Size(162, 41);
            this.btn_print.TabIndex = 14;
            this.btn_print.Text = "출력";
            this.btn_print.UseVisualStyleBackColor = false;
            this.btn_print.Click += new System.EventHandler(this.btn_print_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightYellow;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_print);
            this.Controls.Add(this.btn_create_obj);
            this.Controls.Add(this.txt_result);
            this.Controls.Add(this.txt_mail);
            this.Controls.Add(this.lbl_mail);
            this.Controls.Add(this.txt_Tel);
            this.Controls.Add(this.lbl_Tel);
            this.Controls.Add(this.txt_cellPhone);
            this.Controls.Add(this.lbl_cellPhone);
            this.Controls.Add(this.txt_company);
            this.Controls.Add(this.lbl_company);
            this.Controls.Add(this.txt_age);
            this.Controls.Add(this.lbl_age);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.lbl_name);
            this.Name = "Form1";
            this.Text = "연락처";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.TextBox txt_age;
        private System.Windows.Forms.Label lbl_age;
        private System.Windows.Forms.TextBox txt_company;
        private System.Windows.Forms.Label lbl_company;
        private System.Windows.Forms.TextBox txt_cellPhone;
        private System.Windows.Forms.Label lbl_cellPhone;
        private System.Windows.Forms.TextBox txt_Tel;
        private System.Windows.Forms.Label lbl_Tel;
        private System.Windows.Forms.TextBox txt_mail;
        private System.Windows.Forms.Label lbl_mail;
        private System.Windows.Forms.TextBox txt_result;
        private System.Windows.Forms.Button btn_create_obj;
        private System.Windows.Forms.Button btn_print;
    }
}

