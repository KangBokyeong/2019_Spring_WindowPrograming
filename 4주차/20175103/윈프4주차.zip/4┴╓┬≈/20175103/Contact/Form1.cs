﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// 프로그램명: Contact
/// 프로그램 설명: 정보를 입력 받아서 객체를 생성하고 출력하는 윈도우 프로그램이다.
///               (반드시 객체 생성 후에 출력을 해야한다. 그렇지 않으면 출력 내용이 변경되지 않는다.)
/// 작성일: 2019.03.21(목)
/// 학번, 학과: 20175103, 빅데이터전공
/// 작성자: 강보경
/// </summary>
namespace Contact
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Contact cont;
        // 새로 생성하는 메서드 호출
        private void btn_create_obj_Click(object sender, EventArgs e)
        {
            cont = new Contact(txt_name.Text,Convert.ToInt32(txt_age.Text),txt_company.Text,txt_cellPhone.Text,txt_Tel.Text,txt_mail.Text);

        }
        // 출력하는 메서드 호출
        private void btn_print_Click(object sender, EventArgs e)
        {
            txt_result.Text = cont.ToString();
        }
    }
}
