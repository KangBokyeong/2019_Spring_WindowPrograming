﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// 프로그램명: Comp2Values
/// 프로그램 설명: 두 정수의 크기를 비교해서 결과를 출력하는 프로그램이다.
/// 작성일: 2019.03.14(목)
/// 학번, 학과: 20175103, 빅데이터전공
/// 작성자: 강보경
/// </summary>
namespace Comp2Values
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_cmp_Click(object sender, EventArgs e)
        {
            // 텍스트박스에서 받아와서 정수형으로 변환하여 저장한다.
            int value1 = Convert.ToInt32(txt_integer1.Text);
            int value2 = Convert.ToInt32(txt_integer2.Text);
            
            // 크기 비교 해주기
            if (value1 > value2)    // value1이 더 클 때
            {
                lbl_res.Text = value1 + ">" + value2;   
            }else if(value1 == value2)  // 두 값이 같을 때
            {               
                lbl_res.Text = value1 + "=" + value2;
            }
            else    // value2이 더 클 때
            {
                lbl_res.Text = value1 + "<" + value2;
            }
      

        }
    }
}
