﻿namespace Comp2Values
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_integer1 = new System.Windows.Forms.Label();
            this.lbl_result = new System.Windows.Forms.Label();
            this.txt_integer1 = new System.Windows.Forms.TextBox();
            this.txt_integer2 = new System.Windows.Forms.TextBox();
            this.lbl_integer2 = new System.Windows.Forms.Label();
            this.btn_cmp = new System.Windows.Forms.Button();
            this.lbl_res = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_integer1
            // 
            this.lbl_integer1.AutoSize = true;
            this.lbl_integer1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_integer1.Location = new System.Drawing.Point(78, 61);
            this.lbl_integer1.Name = "lbl_integer1";
            this.lbl_integer1.Size = new System.Drawing.Size(77, 15);
            this.lbl_integer1.TabIndex = 0;
            this.lbl_integer1.Text = "정수 입력";
            // 
            // lbl_result
            // 
            this.lbl_result.AutoSize = true;
            this.lbl_result.Location = new System.Drawing.Point(241, 297);
            this.lbl_result.Name = "lbl_result";
            this.lbl_result.Size = new System.Drawing.Size(0, 15);
            this.lbl_result.TabIndex = 1;
            // 
            // txt_integer1
            // 
            this.txt_integer1.BackColor = System.Drawing.Color.PaleGreen;
            this.txt_integer1.Location = new System.Drawing.Point(160, 57);
            this.txt_integer1.Name = "txt_integer1";
            this.txt_integer1.Size = new System.Drawing.Size(100, 25);
            this.txt_integer1.TabIndex = 2;
            // 
            // txt_integer2
            // 
            this.txt_integer2.BackColor = System.Drawing.Color.PaleGreen;
            this.txt_integer2.Location = new System.Drawing.Point(160, 105);
            this.txt_integer2.Name = "txt_integer2";
            this.txt_integer2.Size = new System.Drawing.Size(100, 25);
            this.txt_integer2.TabIndex = 4;
            // 
            // lbl_integer2
            // 
            this.lbl_integer2.AutoSize = true;
            this.lbl_integer2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_integer2.Location = new System.Drawing.Point(78, 109);
            this.lbl_integer2.Name = "lbl_integer2";
            this.lbl_integer2.Size = new System.Drawing.Size(77, 15);
            this.lbl_integer2.TabIndex = 3;
            this.lbl_integer2.Text = "정수 입력";
            // 
            // btn_cmp
            // 
            this.btn_cmp.BackColor = System.Drawing.Color.Green;
            this.btn_cmp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_cmp.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_cmp.Location = new System.Drawing.Point(113, 167);
            this.btn_cmp.Name = "btn_cmp";
            this.btn_cmp.Size = new System.Drawing.Size(111, 23);
            this.btn_cmp.TabIndex = 5;
            this.btn_cmp.Text = "비교하기";
            this.btn_cmp.UseVisualStyleBackColor = false;
            this.btn_cmp.Click += new System.EventHandler(this.btn_cmp_Click);
            // 
            // lbl_res
            // 
            this.lbl_res.AutoSize = true;
            this.lbl_res.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_res.Location = new System.Drawing.Point(128, 224);
            this.lbl_res.Name = "lbl_res";
            this.lbl_res.Size = new System.Drawing.Size(84, 20);
            this.lbl_res.TabIndex = 6;
            this.lbl_res.Text = "결과는?";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.ClientSize = new System.Drawing.Size(346, 293);
            this.Controls.Add(this.lbl_res);
            this.Controls.Add(this.btn_cmp);
            this.Controls.Add(this.txt_integer2);
            this.Controls.Add(this.lbl_integer2);
            this.Controls.Add(this.txt_integer1);
            this.Controls.Add(this.lbl_result);
            this.Controls.Add(this.lbl_integer1);
            this.Name = "Form1";
            this.Text = "크기 비교";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_integer1;
        private System.Windows.Forms.Label lbl_result;
        private System.Windows.Forms.TextBox txt_integer1;
        private System.Windows.Forms.TextBox txt_integer2;
        private System.Windows.Forms.Label lbl_integer2;
        private System.Windows.Forms.Button btn_cmp;
        private System.Windows.Forms.Label lbl_res;
    }
}

