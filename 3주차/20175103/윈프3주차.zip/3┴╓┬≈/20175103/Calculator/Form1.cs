﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// 프로그램명: Calculator
/// 프로그램 설명: 사칙연산 계산기 프로그램이다.(단, 계산은 입력되는 두 정수의 계산만 수행된다.)
/// 작성일: 2019.03.14(목)
/// 학번, 학과: 20175103, 빅데이터전공
/// 작성자: 강보경
/// </summary>
namespace Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int first = 0;  // 첫번째 정수
        int second = 0; // 두번째 정수
        char op;    // 연산자

        // 0 ~ 9까지 숫자 입력, 0인 경우 처음에 누르면 입력 안됨.
        private void btn_0_Click(object sender, EventArgs e)
        {
            if (txt_output.Text == "")
                txt_output.Text += "";
            else
                txt_output.Text += "0";
        }
        private void btn_1_Click(object sender, EventArgs e)
        {
            txt_output.Text += "1";
        }
        private void btn_2_Click(object sender, EventArgs e)
        {
            txt_output.Text += "2";
        }
        private void btn_3_Click(object sender, EventArgs e)
        {
            txt_output.Text += "3";
        }

        private void btn_4_Click(object sender, EventArgs e)
        {
            txt_output.Text += "4";
        }

        private void btn_5_Click(object sender, EventArgs e)
        {
            txt_output.Text += "5";
        }

        private void btn_6_Click(object sender, EventArgs e)
        {
            txt_output.Text += "6";
        }

        private void btn_7_Click(object sender, EventArgs e)
        {
            txt_output.Text += "7";
        }

        private void btn_8_Click(object sender, EventArgs e)
        {
            txt_output.Text += "8";
        }

        private void btn_9_Click(object sender, EventArgs e)
        {
            txt_output.Text += "9";
        }

        // 더하기 누를 경우, 처음 값을 저장 후 텍스트상자 초기화. 연산자 + 저장
        private void btn_plus_Click(object sender, EventArgs e)
        {
            if(first == 0)
            {
                first = Convert.ToInt32(txt_output.Text);
                txt_output.Text = "";
            }
            op = '+';
        }

        // 뺴기 누를 경우, 처음 값을 저장 후 텍스트상자 초기화. 연산자 - 저장
        private void btn_minus_Click(object sender, EventArgs e)
        {
            if (first == 0)
            {
                first = Convert.ToInt32(txt_output.Text);
                txt_output.Text = "";
            }
            op = '-';
        }

        // 곱하기 누를 경우, 처음 값을 저장 후 텍스트상자 초기화.연산자 * 저장
        private void btn_mult_Click(object sender, EventArgs e)
        {
            if (first == 0)
            {
                first = Convert.ToInt32(txt_output.Text);
                txt_output.Text = "";
            }
            op = '*';
        }

        // 나누기 누를 경우, 처음 값을 저장 후 텍스트상자 초기화. 연산자 /
        private void btn_div_Click(object sender, EventArgs e)
        {
            if (first == 0)
            {
                first = Convert.ToInt32(txt_output.Text);
                txt_output.Text = "";
            }
            op = '/';
        }

        // 연산자 별로 계산( = 를 누를 경우 )
        private void btn_calc_Click(object sender, EventArgs e)
        {
            second = Convert.ToInt32(txt_output.Text);
            txt_output.Text = "";
            
            switch (op)
            {
                case '+':
                    txt_output.Text = Convert.ToString(first + second);  
                    break;
                case '-':
                    txt_output.Text = Convert.ToString(first - second);
                    break;
                case '/':
                    txt_output.Text = Convert.ToString(first / (double)second);
                    break;
                case '*':
                    txt_output.Text = Convert.ToString(first * second);
                    break;
                
            }
        }

        // C를 누를 경우 초기화
        private void btn_C_Click(object sender, EventArgs e)
        {
            first = 0;
            txt_output.Text = "";
        }

        // 현재 텍스트박스에 있는 것만 지워주기
        private void btn_CE_Click(object sender, EventArgs e)
        {
            txt_output.Text = "";
        }
    }
}
