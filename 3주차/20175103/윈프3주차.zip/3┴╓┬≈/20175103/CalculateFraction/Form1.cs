﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// 프로그램명: CalculateFraction
/// 프로그램 설명: 분수 계산이 가능한 윈도우 프로그램이다.
/// 작성일: 2019.03.14(목)
/// 학번, 학과: 20175103, 빅데이터전공
/// 작성자: 강보경
/// </summary>
namespace CalculateFraction
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_calc_Click(object sender, EventArgs e)
        {
            int molecule1 = Convert.ToInt32(txt_molecule1.Text);         // 첫번째 분수의 분자
            int denominator1 = Convert.ToInt32(txt_denominator1.Text);   // 첫번째 분수의 분모

            int molecule2 = Convert.ToInt32(txt_molecule2.Text);         // 두번째 분수의 분자
            int denominator2 = Convert.ToInt32(txt_denominator2.Text);   // 두번째 분수의 분모

            int res_molecule;   // 분자 결과
            int res_denominator;    // 분모 결과
            int gcd; // 최대공약수


            // 분모가 둘다 다를 경우 최대공약수를 찾고
            if(denominator1 != denominator2)
            {
                res_denominator = denominator1 * denominator2;  // 분모는 서로 곱해주기
                // 첫번째 분수의 분자는 두번째 분수에 곱해준 값을 곱하고,
                // 두번째 분수의 분자는 첫번째 분수에 곱해준 값을 곱하여 서로 더해준다.
                res_molecule = (molecule1 * denominator2) + (molecule2 * denominator1);

                
            } else
            {
                res_denominator = denominator1; // 분모는 그대로 둘 다 같기에 아무거나 선택하여 저장한다.
                res_molecule = molecule1 + molecule2; // 분자끼리 더해주기

                
            }
            // 분자 분모를 이용해서 최대공약수 구해주기
            gcd = GCD(res_molecule, res_denominator);

            // 분자, 분모를 앞서 구해준 최대공약수로 나눠준다.
            res_molecule /= gcd;
            res_denominator /= gcd;
            
            
            // 텍스트박스에서 출력시켜주기
            txt_denominator3.Text = Convert.ToString(res_denominator);
            txt_molecule3.Text = Convert.ToString(res_molecule);

        }

        // 최대공약수를 구해주는 함수
        int GCD(int a, int b)
        {
            while (b != 0)
            {
                int temp = a % b;
                a = b;
                b = temp;
            }

            return a;
        }

    }

}
