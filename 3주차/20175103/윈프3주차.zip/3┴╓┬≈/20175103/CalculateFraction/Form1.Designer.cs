﻿namespace CalculateFraction
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_fraction1 = new System.Windows.Forms.Label();
            this.lbl_molecule1 = new System.Windows.Forms.Label();
            this.lbl_denominator1 = new System.Windows.Forms.Label();
            this.lbl_plus = new System.Windows.Forms.Label();
            this.txt_molecule1 = new System.Windows.Forms.TextBox();
            this.txt_denominator1 = new System.Windows.Forms.TextBox();
            this.txt_denominator2 = new System.Windows.Forms.TextBox();
            this.txt_molecule2 = new System.Windows.Forms.TextBox();
            this.lbl_denominator2 = new System.Windows.Forms.Label();
            this.lbl_molecule2 = new System.Windows.Forms.Label();
            this.lbl_fraction2 = new System.Windows.Forms.Label();
            this.txt_denominator3 = new System.Windows.Forms.TextBox();
            this.txt_molecule3 = new System.Windows.Forms.TextBox();
            this.lbl_denominator3 = new System.Windows.Forms.Label();
            this.lbl_molecule3 = new System.Windows.Forms.Label();
            this.lbl_result = new System.Windows.Forms.Label();
            this.btn_calc = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_fraction1
            // 
            this.lbl_fraction1.AutoSize = true;
            this.lbl_fraction1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_fraction1.Location = new System.Drawing.Point(64, 59);
            this.lbl_fraction1.Name = "lbl_fraction1";
            this.lbl_fraction1.Size = new System.Drawing.Size(54, 15);
            this.lbl_fraction1.TabIndex = 0;
            this.lbl_fraction1.Text = "분수 1";
            // 
            // lbl_molecule1
            // 
            this.lbl_molecule1.AutoSize = true;
            this.lbl_molecule1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_molecule1.Location = new System.Drawing.Point(137, 54);
            this.lbl_molecule1.Name = "lbl_molecule1";
            this.lbl_molecule1.Size = new System.Drawing.Size(39, 15);
            this.lbl_molecule1.TabIndex = 1;
            this.lbl_molecule1.Text = "분자";
            // 
            // lbl_denominator1
            // 
            this.lbl_denominator1.AutoSize = true;
            this.lbl_denominator1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_denominator1.Location = new System.Drawing.Point(137, 86);
            this.lbl_denominator1.Name = "lbl_denominator1";
            this.lbl_denominator1.Size = new System.Drawing.Size(39, 15);
            this.lbl_denominator1.TabIndex = 2;
            this.lbl_denominator1.Text = "분모";
            // 
            // lbl_plus
            // 
            this.lbl_plus.AutoSize = true;
            this.lbl_plus.Font = new System.Drawing.Font("굴림", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_plus.Location = new System.Drawing.Point(377, 72);
            this.lbl_plus.Name = "lbl_plus";
            this.lbl_plus.Size = new System.Drawing.Size(19, 19);
            this.lbl_plus.TabIndex = 3;
            this.lbl_plus.Text = "+";
            // 
            // txt_molecule1
            // 
            this.txt_molecule1.BackColor = System.Drawing.Color.LightBlue;
            this.txt_molecule1.Location = new System.Drawing.Point(202, 49);
            this.txt_molecule1.Name = "txt_molecule1";
            this.txt_molecule1.Size = new System.Drawing.Size(100, 25);
            this.txt_molecule1.TabIndex = 4;
            // 
            // txt_denominator1
            // 
            this.txt_denominator1.BackColor = System.Drawing.Color.LightBlue;
            this.txt_denominator1.Location = new System.Drawing.Point(202, 82);
            this.txt_denominator1.Name = "txt_denominator1";
            this.txt_denominator1.Size = new System.Drawing.Size(100, 25);
            this.txt_denominator1.TabIndex = 5;
            // 
            // txt_denominator2
            // 
            this.txt_denominator2.BackColor = System.Drawing.Color.LightBlue;
            this.txt_denominator2.Location = new System.Drawing.Point(605, 81);
            this.txt_denominator2.Name = "txt_denominator2";
            this.txt_denominator2.Size = new System.Drawing.Size(100, 25);
            this.txt_denominator2.TabIndex = 10;
            // 
            // txt_molecule2
            // 
            this.txt_molecule2.BackColor = System.Drawing.Color.LightBlue;
            this.txt_molecule2.Location = new System.Drawing.Point(605, 48);
            this.txt_molecule2.Name = "txt_molecule2";
            this.txt_molecule2.Size = new System.Drawing.Size(100, 25);
            this.txt_molecule2.TabIndex = 9;
            // 
            // lbl_denominator2
            // 
            this.lbl_denominator2.AutoSize = true;
            this.lbl_denominator2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_denominator2.Location = new System.Drawing.Point(540, 85);
            this.lbl_denominator2.Name = "lbl_denominator2";
            this.lbl_denominator2.Size = new System.Drawing.Size(39, 15);
            this.lbl_denominator2.TabIndex = 8;
            this.lbl_denominator2.Text = "분모";
            // 
            // lbl_molecule2
            // 
            this.lbl_molecule2.AutoSize = true;
            this.lbl_molecule2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_molecule2.Location = new System.Drawing.Point(540, 53);
            this.lbl_molecule2.Name = "lbl_molecule2";
            this.lbl_molecule2.Size = new System.Drawing.Size(39, 15);
            this.lbl_molecule2.TabIndex = 7;
            this.lbl_molecule2.Text = "분자";
            // 
            // lbl_fraction2
            // 
            this.lbl_fraction2.AutoSize = true;
            this.lbl_fraction2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_fraction2.Location = new System.Drawing.Point(467, 58);
            this.lbl_fraction2.Name = "lbl_fraction2";
            this.lbl_fraction2.Size = new System.Drawing.Size(54, 15);
            this.lbl_fraction2.TabIndex = 6;
            this.lbl_fraction2.Text = "분수 2";
            // 
            // txt_denominator3
            // 
            this.txt_denominator3.BackColor = System.Drawing.Color.LightBlue;
            this.txt_denominator3.Location = new System.Drawing.Point(417, 197);
            this.txt_denominator3.Name = "txt_denominator3";
            this.txt_denominator3.Size = new System.Drawing.Size(100, 25);
            this.txt_denominator3.TabIndex = 15;
            // 
            // txt_molecule3
            // 
            this.txt_molecule3.BackColor = System.Drawing.Color.LightBlue;
            this.txt_molecule3.Location = new System.Drawing.Point(417, 164);
            this.txt_molecule3.Name = "txt_molecule3";
            this.txt_molecule3.Size = new System.Drawing.Size(100, 25);
            this.txt_molecule3.TabIndex = 14;
            // 
            // lbl_denominator3
            // 
            this.lbl_denominator3.AutoSize = true;
            this.lbl_denominator3.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_denominator3.Location = new System.Drawing.Point(352, 201);
            this.lbl_denominator3.Name = "lbl_denominator3";
            this.lbl_denominator3.Size = new System.Drawing.Size(39, 15);
            this.lbl_denominator3.TabIndex = 13;
            this.lbl_denominator3.Text = "분모";
            // 
            // lbl_molecule3
            // 
            this.lbl_molecule3.AutoSize = true;
            this.lbl_molecule3.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_molecule3.Location = new System.Drawing.Point(352, 169);
            this.lbl_molecule3.Name = "lbl_molecule3";
            this.lbl_molecule3.Size = new System.Drawing.Size(39, 15);
            this.lbl_molecule3.TabIndex = 12;
            this.lbl_molecule3.Text = "분자";
            // 
            // lbl_result
            // 
            this.lbl_result.AutoSize = true;
            this.lbl_result.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_result.Location = new System.Drawing.Point(279, 174);
            this.lbl_result.Name = "lbl_result";
            this.lbl_result.Size = new System.Drawing.Size(39, 15);
            this.lbl_result.TabIndex = 11;
            this.lbl_result.Text = "결과";
            // 
            // btn_calc
            // 
            this.btn_calc.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_calc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_calc.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_calc.Location = new System.Drawing.Point(140, 173);
            this.btn_calc.Name = "btn_calc";
            this.btn_calc.Size = new System.Drawing.Size(30, 23);
            this.btn_calc.TabIndex = 16;
            this.btn_calc.Text = "=";
            this.btn_calc.UseVisualStyleBackColor = false;
            this.btn_calc.Click += new System.EventHandler(this.btn_calc_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 289);
            this.Controls.Add(this.btn_calc);
            this.Controls.Add(this.txt_denominator3);
            this.Controls.Add(this.txt_molecule3);
            this.Controls.Add(this.lbl_denominator3);
            this.Controls.Add(this.lbl_molecule3);
            this.Controls.Add(this.lbl_result);
            this.Controls.Add(this.txt_denominator2);
            this.Controls.Add(this.txt_molecule2);
            this.Controls.Add(this.lbl_denominator2);
            this.Controls.Add(this.lbl_molecule2);
            this.Controls.Add(this.lbl_fraction2);
            this.Controls.Add(this.txt_denominator1);
            this.Controls.Add(this.txt_molecule1);
            this.Controls.Add(this.lbl_plus);
            this.Controls.Add(this.lbl_denominator1);
            this.Controls.Add(this.lbl_molecule1);
            this.Controls.Add(this.lbl_fraction1);
            this.Name = "Form1";
            this.Text = "분수 계산";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_fraction1;
        private System.Windows.Forms.Label lbl_molecule1;
        private System.Windows.Forms.Label lbl_denominator1;
        private System.Windows.Forms.Label lbl_plus;
        private System.Windows.Forms.TextBox txt_molecule1;
        private System.Windows.Forms.TextBox txt_denominator1;
        private System.Windows.Forms.TextBox txt_denominator2;
        private System.Windows.Forms.TextBox txt_molecule2;
        private System.Windows.Forms.Label lbl_denominator2;
        private System.Windows.Forms.Label lbl_molecule2;
        private System.Windows.Forms.Label lbl_fraction2;
        private System.Windows.Forms.TextBox txt_denominator3;
        private System.Windows.Forms.TextBox txt_molecule3;
        private System.Windows.Forms.Label lbl_denominator3;
        private System.Windows.Forms.Label lbl_molecule3;
        private System.Windows.Forms.Label lbl_result;
        private System.Windows.Forms.Button btn_calc;
    }
}

