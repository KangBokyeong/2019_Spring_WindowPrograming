﻿namespace SwapValues
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_value1 = new System.Windows.Forms.Label();
            this.lbl_value2 = new System.Windows.Forms.Label();
            this.txt_value1 = new System.Windows.Forms.TextBox();
            this.txt_value2 = new System.Windows.Forms.TextBox();
            this.btn_swap = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_value1
            // 
            this.lbl_value1.AutoSize = true;
            this.lbl_value1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_value1.Location = new System.Drawing.Point(52, 42);
            this.lbl_value1.Name = "lbl_value1";
            this.lbl_value1.Size = new System.Drawing.Size(56, 15);
            this.lbl_value1.TabIndex = 0;
            this.lbl_value1.Text = "value1";
            // 
            // lbl_value2
            // 
            this.lbl_value2.AutoSize = true;
            this.lbl_value2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_value2.Location = new System.Drawing.Point(312, 42);
            this.lbl_value2.Name = "lbl_value2";
            this.lbl_value2.Size = new System.Drawing.Size(56, 15);
            this.lbl_value2.TabIndex = 1;
            this.lbl_value2.Text = "value2";
            // 
            // txt_value1
            // 
            this.txt_value1.BackColor = System.Drawing.Color.Linen;
            this.txt_value1.Location = new System.Drawing.Point(108, 37);
            this.txt_value1.Name = "txt_value1";
            this.txt_value1.Size = new System.Drawing.Size(100, 25);
            this.txt_value1.TabIndex = 2;
            // 
            // txt_value2
            // 
            this.txt_value2.BackColor = System.Drawing.Color.Linen;
            this.txt_value2.Location = new System.Drawing.Point(368, 37);
            this.txt_value2.Name = "txt_value2";
            this.txt_value2.Size = new System.Drawing.Size(100, 25);
            this.txt_value2.TabIndex = 3;
            // 
            // btn_swap
            // 
            this.btn_swap.BackColor = System.Drawing.Color.DarkOrange;
            this.btn_swap.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_swap.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_swap.Location = new System.Drawing.Point(233, 103);
            this.btn_swap.Name = "btn_swap";
            this.btn_swap.Size = new System.Drawing.Size(75, 23);
            this.btn_swap.TabIndex = 4;
            this.btn_swap.Text = "Swap";
            this.btn_swap.UseVisualStyleBackColor = false;
            this.btn_swap.Click += new System.EventHandler(this.btn_swap_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Bisque;
            this.ClientSize = new System.Drawing.Size(533, 158);
            this.Controls.Add(this.btn_swap);
            this.Controls.Add(this.txt_value2);
            this.Controls.Add(this.txt_value1);
            this.Controls.Add(this.lbl_value2);
            this.Controls.Add(this.lbl_value1);
            this.Name = "Form1";
            this.Text = "Swap App";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_value1;
        private System.Windows.Forms.Label lbl_value2;
        private System.Windows.Forms.TextBox txt_value1;
        private System.Windows.Forms.TextBox txt_value2;
        private System.Windows.Forms.Button btn_swap;
    }
}

