﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// 프로그램명: SwapValues
/// 프로그램 설명: Swap 버튼을 클릭하면 value1과 value2의 텍스트박스 내용을 바꾸는 프로그램이다.
/// 작성일: 2019.03.14(목)
/// 학번, 학과: 20175103, 빅데이터전공
/// 작성자: 강보경
/// </summary>
namespace SwapValues
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // 값을 포인터로 받아서 서로 교환해준다.
        unsafe public static void Swap(int* value1, int* value2)
        {
            int tmp = *value1;
            *value1 = *value2;
            *value2 = tmp;
        }

        private void btn_swap_Click(object sender, EventArgs e)
        {
            // 스왑 해주기 위해 텍스트에 있는 문자열을 정수형으로 받아와서 저장한다.
            int value1 = Convert.ToInt32(txt_value1.Text);
            int value2 = Convert.ToInt32(txt_value2.Text);

            // 텍스트 내용 초기화
            txt_value1.Text = txt_value2.Text = "";

            // 스왑 함수 호출
            unsafe
            {
                Swap(&value1, &value2);
            }

            // 문자열을 텍스트에 입력해준다.
            txt_value1.Text += Convert.ToString(value1);    
            txt_value2.Text += Convert.ToString(value2);    

        }


        

    }
}
