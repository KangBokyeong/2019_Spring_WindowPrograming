﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// 프로그램명: ObesityCalc
/// 프로그램 설명: 비만도를 계산하는 프로그램이다.
/// 작성일: 2019.03.14(목)
/// 학번, 학과: 20175103, 빅데이터전공
/// 작성자: 강보경
/// </summary>
namespace ObesityCalc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_calc_Click(object sender, EventArgs e)
        {
            double height = Convert.ToDouble(txt_height.Text);   // 키 변수
            double weight = Convert.ToDouble(txt_weight.Text);   // 몸무게 변수
            double standard_weight = 0.0 ; // 표준체중 변수
            double bmi; // 비만지수 변수
            string obesity = ""; // 비만도 변수

            // 표준체중 계산[표준체중 = (키 - 100) * 0.9]
            standard_weight = (height - 100) * 0.9;

            // 비만지수 계산[비만지수 = (몸무게 - 표준체중) / 표준체중 * 100]
            bmi = (weight - standard_weight) / standard_weight * 100.0;

            // 표준체중, 비만지수 표시
            txt_standardW.Text = Convert.ToString(standard_weight);
            txt_BMI.Text = Convert.ToString(bmi);

            // 비만도 별 출력
            /*
                 비만도 평가
            비만지수: 20 미만->정상
            비만지수: 20~30->경도비만
            비만지수: 30~50->중도비만
            비만지수: 50 이상->고도비만
            */
            if (bmi < 20)
            {
                obesity = "정상";

            }else if(bmi < 30)
            {
                obesity = "경도비만";
            }
            else if(bmi < 50)
            {
                obesity = "중도비만";
            }
            else if(bmi >= 50)
            {
                obesity = "고도비만";
            }

            txt_obesity.Text = obesity;
        }
    }
}
