﻿namespace ObesityCalc
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_height = new System.Windows.Forms.Label();
            this.txt_height = new System.Windows.Forms.TextBox();
            this.txt_weight = new System.Windows.Forms.TextBox();
            this.lbl_weight = new System.Windows.Forms.Label();
            this.txt_standardW = new System.Windows.Forms.TextBox();
            this.lbl_standardW = new System.Windows.Forms.Label();
            this.txt_BMI = new System.Windows.Forms.TextBox();
            this.lbl_BMI = new System.Windows.Forms.Label();
            this.txt_obesity = new System.Windows.Forms.TextBox();
            this.lbl_obesity = new System.Windows.Forms.Label();
            this.btn_calc = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_height
            // 
            this.lbl_height.AutoSize = true;
            this.lbl_height.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbl_height.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_height.Location = new System.Drawing.Point(65, 85);
            this.lbl_height.Name = "lbl_height";
            this.lbl_height.Size = new System.Drawing.Size(23, 15);
            this.lbl_height.TabIndex = 0;
            this.lbl_height.Text = "키";
            // 
            // txt_height
            // 
            this.txt_height.BackColor = System.Drawing.Color.Orchid;
            this.txt_height.Location = new System.Drawing.Point(182, 80);
            this.txt_height.Name = "txt_height";
            this.txt_height.Size = new System.Drawing.Size(185, 25);
            this.txt_height.TabIndex = 1;
            // 
            // txt_weight
            // 
            this.txt_weight.BackColor = System.Drawing.Color.Orchid;
            this.txt_weight.Location = new System.Drawing.Point(182, 122);
            this.txt_weight.Name = "txt_weight";
            this.txt_weight.Size = new System.Drawing.Size(185, 25);
            this.txt_weight.TabIndex = 3;
            // 
            // lbl_weight
            // 
            this.lbl_weight.AutoSize = true;
            this.lbl_weight.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbl_weight.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_weight.Location = new System.Drawing.Point(65, 127);
            this.lbl_weight.Name = "lbl_weight";
            this.lbl_weight.Size = new System.Drawing.Size(55, 15);
            this.lbl_weight.TabIndex = 2;
            this.lbl_weight.Text = "몸무게";
            // 
            // txt_standardW
            // 
            this.txt_standardW.BackColor = System.Drawing.Color.Orchid;
            this.txt_standardW.Location = new System.Drawing.Point(186, 231);
            this.txt_standardW.Name = "txt_standardW";
            this.txt_standardW.Size = new System.Drawing.Size(185, 25);
            this.txt_standardW.TabIndex = 5;
            // 
            // lbl_standardW
            // 
            this.lbl_standardW.AutoSize = true;
            this.lbl_standardW.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbl_standardW.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_standardW.Location = new System.Drawing.Point(69, 236);
            this.lbl_standardW.Name = "lbl_standardW";
            this.lbl_standardW.Size = new System.Drawing.Size(71, 15);
            this.lbl_standardW.TabIndex = 4;
            this.lbl_standardW.Text = "표준체중";
            // 
            // txt_BMI
            // 
            this.txt_BMI.BackColor = System.Drawing.Color.Orchid;
            this.txt_BMI.Location = new System.Drawing.Point(186, 281);
            this.txt_BMI.Name = "txt_BMI";
            this.txt_BMI.Size = new System.Drawing.Size(185, 25);
            this.txt_BMI.TabIndex = 7;
            // 
            // lbl_BMI
            // 
            this.lbl_BMI.AutoSize = true;
            this.lbl_BMI.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbl_BMI.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_BMI.Location = new System.Drawing.Point(69, 286);
            this.lbl_BMI.Name = "lbl_BMI";
            this.lbl_BMI.Size = new System.Drawing.Size(113, 15);
            this.lbl_BMI.TabIndex = 6;
            this.lbl_BMI.Text = "비만지수(BMI)";
            // 
            // txt_obesity
            // 
            this.txt_obesity.BackColor = System.Drawing.Color.Orchid;
            this.txt_obesity.Location = new System.Drawing.Point(186, 333);
            this.txt_obesity.Name = "txt_obesity";
            this.txt_obesity.Size = new System.Drawing.Size(185, 25);
            this.txt_obesity.TabIndex = 9;
            // 
            // lbl_obesity
            // 
            this.lbl_obesity.AutoSize = true;
            this.lbl_obesity.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbl_obesity.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_obesity.Location = new System.Drawing.Point(69, 338);
            this.lbl_obesity.Name = "lbl_obesity";
            this.lbl_obesity.Size = new System.Drawing.Size(55, 15);
            this.lbl_obesity.TabIndex = 8;
            this.lbl_obesity.Text = "비만도";
            // 
            // btn_calc
            // 
            this.btn_calc.BackColor = System.Drawing.Color.MediumOrchid;
            this.btn_calc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_calc.Font = new System.Drawing.Font("굴림", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_calc.Location = new System.Drawing.Point(162, 164);
            this.btn_calc.Name = "btn_calc";
            this.btn_calc.Size = new System.Drawing.Size(137, 50);
            this.btn_calc.TabIndex = 10;
            this.btn_calc.Text = "확인";
            this.btn_calc.UseVisualStyleBackColor = false;
            this.btn_calc.Click += new System.EventHandler(this.btn_calc_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(441, 432);
            this.Controls.Add(this.btn_calc);
            this.Controls.Add(this.txt_obesity);
            this.Controls.Add(this.lbl_obesity);
            this.Controls.Add(this.txt_BMI);
            this.Controls.Add(this.lbl_BMI);
            this.Controls.Add(this.txt_standardW);
            this.Controls.Add(this.lbl_standardW);
            this.Controls.Add(this.txt_weight);
            this.Controls.Add(this.lbl_weight);
            this.Controls.Add(this.txt_height);
            this.Controls.Add(this.lbl_height);
            this.Name = "Form1";
            this.Text = "비만도 계산기";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_height;
        private System.Windows.Forms.TextBox txt_height;
        private System.Windows.Forms.TextBox txt_weight;
        private System.Windows.Forms.Label lbl_weight;
        private System.Windows.Forms.TextBox txt_standardW;
        private System.Windows.Forms.Label lbl_standardW;
        private System.Windows.Forms.TextBox txt_BMI;
        private System.Windows.Forms.Label lbl_BMI;
        private System.Windows.Forms.TextBox txt_obesity;
        private System.Windows.Forms.Label lbl_obesity;
        private System.Windows.Forms.Button btn_calc;
    }
}

