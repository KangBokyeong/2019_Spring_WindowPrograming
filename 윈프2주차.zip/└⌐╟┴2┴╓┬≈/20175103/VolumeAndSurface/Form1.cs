﻿/// <summary>
/// 프로그램명: VolumeAndSurface
/// 프로그램 설명: 반지름을 입력하고 그 반지름에 대한 부피와 표면에 대한 넓이를 구하는 프로그램이다.
/// 작성일: 2019.03.07(목)
/// 작성자: 강보경
/// </summary>

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VolumeAndSurface
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // PI에 대한 값은 변동이 없으므로 static으로 설정해 주었다.
        static readonly double PI = 3.14;
        
        private void button1_Click(object sender, EventArgs e)
        {
            // 반지름을 저장하기 위해 r이라는 변수를 만들어 주고
            // textBox1에서 입력 받은 값이 문자열이므로 정수값으로 변환해주고 이후에 계산한다.
            double r = Convert.ToDouble(txt_r.Text);

            /*
             * 부피 및 표면적 계산
             * 부피(volume) = r * r * r * PI * 4 / 3
             * 표면적(surface) = r * r * 4 * PI
             */

            double volume = r * r * r * PI * 4 / 3;
            double surface = r * r * 4 * PI;

            // 계산한 결과를 각각의 textBox에 출력시킨다.(문자열로 변환하여 출력)
            txt_volume.Text = Convert.ToString(volume);   // 부피
            txt_surface.Text = Convert.ToString(surface);   // 표면적

        }
        
    }
}
