﻿namespace VolumeAndSurface
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_r = new System.Windows.Forms.Label();
            this.lbl_volume = new System.Windows.Forms.Label();
            this.lbl_surface = new System.Windows.Forms.Label();
            this.txt_r = new System.Windows.Forms.TextBox();
            this.txt_volume = new System.Windows.Forms.TextBox();
            this.txt_surface = new System.Windows.Forms.TextBox();
            this.btn_cal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_r
            // 
            this.lbl_r.AutoSize = true;
            this.lbl_r.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_r.Location = new System.Drawing.Point(129, 104);
            this.lbl_r.Name = "lbl_r";
            this.lbl_r.Size = new System.Drawing.Size(80, 15);
            this.lbl_r.TabIndex = 0;
            this.lbl_r.Text = "반지름(R)";
            // 
            // lbl_volume
            // 
            this.lbl_volume.AutoSize = true;
            this.lbl_volume.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_volume.Location = new System.Drawing.Point(129, 230);
            this.lbl_volume.Name = "lbl_volume";
            this.lbl_volume.Size = new System.Drawing.Size(62, 15);
            this.lbl_volume.TabIndex = 1;
            this.lbl_volume.Text = "부피(V)";
            // 
            // lbl_surface
            // 
            this.lbl_surface.AutoSize = true;
            this.lbl_surface.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_surface.Location = new System.Drawing.Point(129, 304);
            this.lbl_surface.Name = "lbl_surface";
            this.lbl_surface.Size = new System.Drawing.Size(80, 15);
            this.lbl_surface.TabIndex = 2;
            this.lbl_surface.Text = "표면적(S)";
            // 
            // txt_r
            // 
            this.txt_r.Location = new System.Drawing.Point(233, 99);
            this.txt_r.Name = "txt_r";
            this.txt_r.Size = new System.Drawing.Size(273, 25);
            this.txt_r.TabIndex = 3;
            // 
            // txt_volume
            // 
            this.txt_volume.Location = new System.Drawing.Point(233, 226);
            this.txt_volume.Name = "txt_volume";
            this.txt_volume.Size = new System.Drawing.Size(273, 25);
            this.txt_volume.TabIndex = 4;
            // 
            // txt_surface
            // 
            this.txt_surface.Location = new System.Drawing.Point(233, 300);
            this.txt_surface.Name = "txt_surface";
            this.txt_surface.Size = new System.Drawing.Size(273, 25);
            this.txt_surface.TabIndex = 5;
            // 
            // btn_cal
            // 
            this.btn_cal.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_cal.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_cal.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_cal.Location = new System.Drawing.Point(309, 166);
            this.btn_cal.Name = "btn_cal";
            this.btn_cal.Size = new System.Drawing.Size(125, 23);
            this.btn_cal.TabIndex = 6;
            this.btn_cal.Text = "Execute";
            this.btn_cal.UseVisualStyleBackColor = false;
            this.btn_cal.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(687, 450);
            this.Controls.Add(this.btn_cal);
            this.Controls.Add(this.txt_surface);
            this.Controls.Add(this.txt_volume);
            this.Controls.Add(this.txt_r);
            this.Controls.Add(this.lbl_surface);
            this.Controls.Add(this.lbl_volume);
            this.Controls.Add(this.lbl_r);
            this.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Name = "Form1";
            this.Text = "부피 및 표면적";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_r;
        private System.Windows.Forms.Label lbl_volume;
        private System.Windows.Forms.Label lbl_surface;
        private System.Windows.Forms.TextBox txt_r;
        private System.Windows.Forms.TextBox txt_volume;
        private System.Windows.Forms.TextBox txt_surface;
        private System.Windows.Forms.Button btn_cal;
    }
}

