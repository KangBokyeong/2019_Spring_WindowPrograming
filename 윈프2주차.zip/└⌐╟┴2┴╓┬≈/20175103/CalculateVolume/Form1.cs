﻿/// <summary>
/// 프로그램명: CalculateVolume
/// 프로그램 설명: 길이, 너비, 높이를 입력 받고 부피의 크기를 구하는 프로그램이다.
/// 작성일: 2019.03.07(목)
/// 작성자: 강보경
/// </summary>

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculateVolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*
             * 길이, 너비, 높이 값을 각각의 텍스트박스에서 입력을 받아서
             * (받아온 입력값은 문자열이기에) 자료형을 int로 변환 시켜준다.
             * 각각 어떤 값인 지 알기 쉽도록 길이는 length, 너비는 width, 높이는 height로 설정해 두었다.
             */
            int length = Convert.ToInt32(txt_length.Text);
            int width = Convert.ToInt32(txt_width.Text);
            int height = Convert.ToInt32(txt_height.Text);

            // 부피를 구하기 위해 길이, 너비, 높이를 서로 곱해주어 volume이라는 곳에 부피의 값을 저장하였다.
            int volume = length * width * height;

            // volume은 정수이므로 textBox4에 나타내려면 문자열로 출력이 되어야 하므로 문자열로 형변환을 시켜준 다음에 저장한다.
            txt_result.Text = Convert.ToString(volume);

        }
    }
}
