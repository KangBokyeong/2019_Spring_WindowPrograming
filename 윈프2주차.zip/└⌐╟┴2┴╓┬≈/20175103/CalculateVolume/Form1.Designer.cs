﻿namespace CalculateVolume
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_length = new System.Windows.Forms.Label();
            this.lbl_width = new System.Windows.Forms.Label();
            this.lbl_height = new System.Windows.Forms.Label();
            this.lbl_result = new System.Windows.Forms.Label();
            this.txt_length = new System.Windows.Forms.TextBox();
            this.txt_width = new System.Windows.Forms.TextBox();
            this.txt_height = new System.Windows.Forms.TextBox();
            this.txt_result = new System.Windows.Forms.TextBox();
            this.btn_calc = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_length
            // 
            this.lbl_length.AutoSize = true;
            this.lbl_length.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_length.Location = new System.Drawing.Point(112, 65);
            this.lbl_length.Name = "lbl_length";
            this.lbl_length.Size = new System.Drawing.Size(39, 15);
            this.lbl_length.TabIndex = 0;
            this.lbl_length.Text = "길이";
            // 
            // lbl_width
            // 
            this.lbl_width.AutoSize = true;
            this.lbl_width.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_width.Location = new System.Drawing.Point(112, 120);
            this.lbl_width.Name = "lbl_width";
            this.lbl_width.Size = new System.Drawing.Size(39, 15);
            this.lbl_width.TabIndex = 1;
            this.lbl_width.Text = "너비";
            // 
            // lbl_height
            // 
            this.lbl_height.AutoSize = true;
            this.lbl_height.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_height.Location = new System.Drawing.Point(112, 178);
            this.lbl_height.Name = "lbl_height";
            this.lbl_height.Size = new System.Drawing.Size(39, 15);
            this.lbl_height.TabIndex = 2;
            this.lbl_height.Text = "높이";
            // 
            // lbl_result
            // 
            this.lbl_result.AutoSize = true;
            this.lbl_result.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_result.Location = new System.Drawing.Point(112, 307);
            this.lbl_result.Name = "lbl_result";
            this.lbl_result.Size = new System.Drawing.Size(39, 15);
            this.lbl_result.TabIndex = 3;
            this.lbl_result.Text = "결과";
            // 
            // txt_length
            // 
            this.txt_length.Location = new System.Drawing.Point(173, 62);
            this.txt_length.Name = "txt_length";
            this.txt_length.Size = new System.Drawing.Size(265, 25);
            this.txt_length.TabIndex = 4;
            // 
            // txt_width
            // 
            this.txt_width.Location = new System.Drawing.Point(173, 116);
            this.txt_width.Name = "txt_width";
            this.txt_width.Size = new System.Drawing.Size(265, 25);
            this.txt_width.TabIndex = 5;
            // 
            // txt_height
            // 
            this.txt_height.Location = new System.Drawing.Point(173, 175);
            this.txt_height.Name = "txt_height";
            this.txt_height.Size = new System.Drawing.Size(265, 25);
            this.txt_height.TabIndex = 6;
            // 
            // txt_result
            // 
            this.txt_result.Location = new System.Drawing.Point(173, 304);
            this.txt_result.Multiline = true;
            this.txt_result.Name = "txt_result";
            this.txt_result.Size = new System.Drawing.Size(265, 80);
            this.txt_result.TabIndex = 7;
            // 
            // btn_calc
            // 
            this.btn_calc.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_calc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_calc.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_calc.Location = new System.Drawing.Point(256, 242);
            this.btn_calc.Name = "btn_calc";
            this.btn_calc.Size = new System.Drawing.Size(88, 23);
            this.btn_calc.TabIndex = 8;
            this.btn_calc.Text = "Execute";
            this.btn_calc.UseVisualStyleBackColor = false;
            this.btn_calc.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.GhostWhite;
            this.ClientSize = new System.Drawing.Size(584, 415);
            this.Controls.Add(this.btn_calc);
            this.Controls.Add(this.txt_result);
            this.Controls.Add(this.txt_height);
            this.Controls.Add(this.txt_width);
            this.Controls.Add(this.txt_length);
            this.Controls.Add(this.lbl_result);
            this.Controls.Add(this.lbl_height);
            this.Controls.Add(this.lbl_width);
            this.Controls.Add(this.lbl_length);
            this.Name = "Form1";
            this.Text = "사각형 부피 계산";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_length;
        private System.Windows.Forms.Label lbl_width;
        private System.Windows.Forms.Label lbl_height;
        private System.Windows.Forms.Label lbl_result;
        private System.Windows.Forms.TextBox txt_length;
        private System.Windows.Forms.TextBox txt_width;
        private System.Windows.Forms.TextBox txt_height;
        private System.Windows.Forms.TextBox txt_result;
        private System.Windows.Forms.Button btn_calc;
    }
}

