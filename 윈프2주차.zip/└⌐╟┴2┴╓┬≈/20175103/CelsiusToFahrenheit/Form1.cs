﻿/// <summary>
/// 프로그램명: CelsiusToFahrenheit
/// 프로그램 설명: 섭씨를 입력받아 화씨로 반환시켜서 출력하는 프로그램이다. 
/// 작성일: 2019.03.07(목)
/// 작성자: 강보경
/// </summary>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CelsiusToFahrenheit
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 입력을 받은 값을 정수형으로 변환시켜 저장해주었다.
            double Celsius = Convert.ToDouble(txt_cel.Text);
            // 계산: 섭씨를 화씨를 계산하는 문장이다.
            double Fahrenheit = Celsius * (double)(9 / 5) + 32;

            // 문자열로 출력시키기 위해 문자열로 변환시켜주었다.
            txt_fah.Text = Convert.ToString(Fahrenheit);
        }
    }
}
