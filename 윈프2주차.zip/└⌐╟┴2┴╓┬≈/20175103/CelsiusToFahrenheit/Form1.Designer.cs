﻿namespace CelsiusToFahrenheit
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_cel = new System.Windows.Forms.Label();
            this.lbl_fah = new System.Windows.Forms.Label();
            this.txt_cel = new System.Windows.Forms.TextBox();
            this.txt_fah = new System.Windows.Forms.TextBox();
            this.btn_cal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_cel
            // 
            this.lbl_cel.AutoSize = true;
            this.lbl_cel.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_cel.Location = new System.Drawing.Point(141, 87);
            this.lbl_cel.Name = "lbl_cel";
            this.lbl_cel.Size = new System.Drawing.Size(39, 15);
            this.lbl_cel.TabIndex = 0;
            this.lbl_cel.Text = "섭씨";
            // 
            // lbl_fah
            // 
            this.lbl_fah.AutoSize = true;
            this.lbl_fah.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_fah.Location = new System.Drawing.Point(141, 233);
            this.lbl_fah.Name = "lbl_fah";
            this.lbl_fah.Size = new System.Drawing.Size(39, 15);
            this.lbl_fah.TabIndex = 1;
            this.lbl_fah.Text = "화씨";
            // 
            // txt_cel
            // 
            this.txt_cel.Location = new System.Drawing.Point(213, 82);
            this.txt_cel.Name = "txt_cel";
            this.txt_cel.Size = new System.Drawing.Size(257, 25);
            this.txt_cel.TabIndex = 2;
            // 
            // txt_fah
            // 
            this.txt_fah.Location = new System.Drawing.Point(213, 230);
            this.txt_fah.Name = "txt_fah";
            this.txt_fah.Size = new System.Drawing.Size(257, 25);
            this.txt_fah.TabIndex = 3;
            // 
            // btn_cal
            // 
            this.btn_cal.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_cal.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_cal.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_cal.Location = new System.Drawing.Point(279, 156);
            this.btn_cal.Name = "btn_cal";
            this.btn_cal.Size = new System.Drawing.Size(121, 23);
            this.btn_cal.TabIndex = 4;
            this.btn_cal.Text = "Execute";
            this.btn_cal.UseVisualStyleBackColor = false;
            this.btn_cal.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.GhostWhite;
            this.ClientSize = new System.Drawing.Size(663, 337);
            this.Controls.Add(this.btn_cal);
            this.Controls.Add(this.txt_fah);
            this.Controls.Add(this.txt_cel);
            this.Controls.Add(this.lbl_fah);
            this.Controls.Add(this.lbl_cel);
            this.Name = "Form1";
            this.Text = "섭씨/화씨 변환";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_cel;
        private System.Windows.Forms.Label lbl_fah;
        private System.Windows.Forms.TextBox txt_cel;
        private System.Windows.Forms.TextBox txt_fah;
        private System.Windows.Forms.Button btn_cal;
    }
}

