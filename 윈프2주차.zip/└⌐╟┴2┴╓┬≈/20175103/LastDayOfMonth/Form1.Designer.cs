﻿namespace LastDayOfMonth
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_month = new System.Windows.Forms.Label();
            this.lbl_day = new System.Windows.Forms.Label();
            this.txt_month = new System.Windows.Forms.TextBox();
            this.txt_day = new System.Windows.Forms.TextBox();
            this.btn_cal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_month
            // 
            this.lbl_month.AutoSize = true;
            this.lbl_month.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_month.Location = new System.Drawing.Point(77, 86);
            this.lbl_month.Name = "lbl_month";
            this.lbl_month.Size = new System.Drawing.Size(23, 15);
            this.lbl_month.TabIndex = 0;
            this.lbl_month.Text = "월";
            // 
            // lbl_day
            // 
            this.lbl_day.AutoSize = true;
            this.lbl_day.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_day.Location = new System.Drawing.Point(77, 205);
            this.lbl_day.Name = "lbl_day";
            this.lbl_day.Size = new System.Drawing.Size(23, 15);
            this.lbl_day.TabIndex = 1;
            this.lbl_day.Text = "일";
            // 
            // txt_month
            // 
            this.txt_month.Location = new System.Drawing.Point(120, 83);
            this.txt_month.Name = "txt_month";
            this.txt_month.Size = new System.Drawing.Size(62, 25);
            this.txt_month.TabIndex = 2;
            // 
            // txt_day
            // 
            this.txt_day.Location = new System.Drawing.Point(120, 200);
            this.txt_day.Name = "txt_day";
            this.txt_day.Size = new System.Drawing.Size(62, 25);
            this.txt_day.TabIndex = 3;
            // 
            // btn_cal
            // 
            this.btn_cal.BackColor = System.Drawing.Color.DarkGray;
            this.btn_cal.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_cal.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_cal.Location = new System.Drawing.Point(104, 143);
            this.btn_cal.Name = "btn_cal";
            this.btn_cal.Size = new System.Drawing.Size(89, 23);
            this.btn_cal.TabIndex = 4;
            this.btn_cal.Text = "Execute";
            this.btn_cal.UseVisualStyleBackColor = false;
            this.btn_cal.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cornsilk;
            this.ClientSize = new System.Drawing.Size(267, 297);
            this.Controls.Add(this.btn_cal);
            this.Controls.Add(this.txt_day);
            this.Controls.Add(this.txt_month);
            this.Controls.Add(this.lbl_day);
            this.Controls.Add(this.lbl_month);
            this.Name = "Form1";
            this.Text = "월";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_month;
        private System.Windows.Forms.Label lbl_day;
        private System.Windows.Forms.TextBox txt_month;
        private System.Windows.Forms.TextBox txt_day;
        private System.Windows.Forms.Button btn_cal;
    }
}

