﻿/// <summary>
/// 프로그램명: LastDayOfMonth
/// 프로그램 설명: 월을 입력 받으면 해당 월의 마지막 일이 몇 일인지를 출력시켜주는 프로그램이다. 
/// 작성일: 2019.03.07(목)
/// 작성자: 강보경
/// </summary>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LastDayOfMonth
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 입력 받은 값을 정수로 받아서 변수에 저장하여 후에 사용한다.
            int month = Convert.ToInt32(txt_month.Text);

            // 입력 받은 월은 switch문을 이용하여 구분해 준다.
            // 28일이 마지막인 날: 2
            // 31일이 마지막인 날: 1, 3, 5, 7, 8, 10, 12
            // 30일이 마지막인 날: 4, 6, 9, 11
            // 그것도 아니고 저것도 아니면 Error!를 출력시켜준다.

            switch (month)
            {
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:
                    txt_day.Text = "31";
                    break;
                case 2:
                    txt_day.Text = "28";
                    break;
                case 4:
                case 6:
                case 9:
                case 11:
                    txt_day.Text = "30";
                    break;
                default:
                    txt_day.Text = "Error!";
                    break;
            }
        }
    }
}
