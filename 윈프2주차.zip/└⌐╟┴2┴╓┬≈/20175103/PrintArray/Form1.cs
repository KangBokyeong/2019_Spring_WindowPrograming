﻿/// <summary>
/// 프로그램명: PrintArray
/// 프로그램 설명: 이미 사전에 저장되어 있는 1차원 배열을 출력시켜주는 프로그램이다. 
/// 작성일: 2019.03.07(목)
/// 작성자: 강보경
/// </summary>

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrintArray
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 1차원 배열을 선언 및 초기화
            int[] arr = { 1, 3, 4, 5, 6, 7, 9, 8, 2, 0 };

            // 마지막
            for(int i = 0; i < arr.Length; i++)
            {
                // 마지막은 ,을 출력시키지 않기 때문에 하나 이전까지는 출력켜주고
                if(i < arr.Length - 1)
                    txt_result.Text += arr[i]+ ", ";
                // 마지막까지 오면 ,를 출력시키지 않는다.
                else
                    txt_result.Text += arr[i];

            }


        }
    }
}
