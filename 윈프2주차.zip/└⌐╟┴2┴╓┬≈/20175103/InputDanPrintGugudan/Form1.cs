﻿/// <summary>
/// 프로그램명: InputDanPrintGugudan
/// 프로그램 설명: 단을 입력 받으면 구구단 결과를 출력하는 프로그램이다. 
/// 작성일: 2019.03.07(목)
/// 작성자: 강보경
/// </summary>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InputDanPrintGugudan
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // textBox1에 있는 것을 문자열에서 정수로 변환시켜준 후 변수에 저장한다.
            int dan = Convert.ToInt32(txt_dan.Text);
            // 이전에 있던 문자열들을 초기화(이전에 기록들을 화면에서 삭제)
            txt_resullt.Text = "";
            // 위에서 저장한 변수를 이용해여 출력시켜준다. (for문 이용)
            for (int i = 1; i < 10; i++)
            {
                txt_resullt.Text += dan + "*" + i +"="+ (dan * i) + Environment.NewLine;
            }

        }
    }
}
