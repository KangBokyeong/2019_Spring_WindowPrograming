﻿namespace InputDanPrintGugudan
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_dan = new System.Windows.Forms.Label();
            this.lbl_result = new System.Windows.Forms.Label();
            this.txt_dan = new System.Windows.Forms.TextBox();
            this.txt_resullt = new System.Windows.Forms.TextBox();
            this.btn_cal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_dan
            // 
            this.lbl_dan.AutoSize = true;
            this.lbl_dan.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_dan.Location = new System.Drawing.Point(62, 79);
            this.lbl_dan.Name = "lbl_dan";
            this.lbl_dan.Size = new System.Drawing.Size(23, 15);
            this.lbl_dan.TabIndex = 0;
            this.lbl_dan.Text = "단";
            // 
            // lbl_result
            // 
            this.lbl_result.AutoSize = true;
            this.lbl_result.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_result.Location = new System.Drawing.Point(62, 218);
            this.lbl_result.Name = "lbl_result";
            this.lbl_result.Size = new System.Drawing.Size(39, 15);
            this.lbl_result.TabIndex = 1;
            this.lbl_result.Text = "출력";
            // 
            // txt_dan
            // 
            this.txt_dan.Location = new System.Drawing.Point(122, 75);
            this.txt_dan.Name = "txt_dan";
            this.txt_dan.Size = new System.Drawing.Size(51, 25);
            this.txt_dan.TabIndex = 2;
            // 
            // txt_resullt
            // 
            this.txt_resullt.Location = new System.Drawing.Point(122, 215);
            this.txt_resullt.Multiline = true;
            this.txt_resullt.Name = "txt_resullt";
            this.txt_resullt.Size = new System.Drawing.Size(130, 183);
            this.txt_resullt.TabIndex = 3;
            // 
            // btn_cal
            // 
            this.btn_cal.BackColor = System.Drawing.Color.DarkSalmon;
            this.btn_cal.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_cal.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_cal.Location = new System.Drawing.Point(134, 146);
            this.btn_cal.Name = "btn_cal";
            this.btn_cal.Size = new System.Drawing.Size(106, 23);
            this.btn_cal.TabIndex = 4;
            this.btn_cal.Text = "Execute";
            this.btn_cal.UseVisualStyleBackColor = false;
            this.btn_cal.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cornsilk;
            this.ClientSize = new System.Drawing.Size(329, 450);
            this.Controls.Add(this.btn_cal);
            this.Controls.Add(this.txt_resullt);
            this.Controls.Add(this.txt_dan);
            this.Controls.Add(this.lbl_result);
            this.Controls.Add(this.lbl_dan);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Form1";
            this.Text = "구구단 출력";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_dan;
        private System.Windows.Forms.Label lbl_result;
        private System.Windows.Forms.TextBox txt_dan;
        private System.Windows.Forms.TextBox txt_resullt;
        private System.Windows.Forms.Button btn_cal;
    }
}

